package com.zenflow.game

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zenflow.game.ui.screens.GameScreen
import com.zenflow.game.ui.screens.HomeScreen
import com.zenflow.game.ui.screens.LevelSelectScreen

@Composable
fun ZenFlowApp() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                onPlayClick = {
                    navController.navigate("levelSelect")
                }
            )
        }
        composable("levelSelect") {
            LevelSelectScreen(
                onLevelClick = { levelId ->
                    navController.navigate("game/$levelId")
                },
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }
        composable(
            route = "game/{levelId}",
            arguments = listOf(
                navArgument("levelId") {
                    type = NavType.IntType
                    defaultValue = 1
                }
            )
        ) { backStackEntry ->
            val levelId = backStackEntry.arguments?.getInt("levelId") ?: 1
            GameScreen(
                levelId = levelId,
                onBackClick = {
                    navController.popBackStack()
                },
                onNextLevel = { nextLevelId ->
                    navController.navigate("game/$nextLevelId") {
                        popUpTo("levelSelect")
                    }
                }
            )
        }
    }
}
