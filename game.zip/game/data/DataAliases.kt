package com.zenflow.game.data

typealias LevelRepository = com.zenflow.game.game.data.LevelRepository
