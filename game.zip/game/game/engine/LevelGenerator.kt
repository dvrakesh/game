package com.zenflow.game.game.engine

import com.zenflow.game.game.model.FlowColor
import com.zenflow.game.game.model.Level
import com.zenflow.game.game.model.Point
import kotlin.random.Random

/**
 * Procedural level generator for ZenFlow puzzle game.
 *
 * Generates unlimited, guaranteed-solvable Flow Connect puzzles with
 * progressive difficulty scaling across chapters.
 *
 * Key Design Principles:
 * 1. Solution-First Generation: Generates complete, non-overlapping simple paths
 *    that fill 100% of the grid first. Endpoints are then extracted from path ends.
 *    This guarantees mathematical solvability and 100% board coverage.
 * 2. Deterministic Reproducibility: Uses `Random(seed = levelId.toLong() * 31 + 1337)`
 *    so any level ID always produces the identical puzzle.
 * 3. Difficulty Curve: Grid sizes scale from 5x5 up to 12x12, and flow counts scale
 *    from 3 colors up to 8 colors.
 * 4. Solution Cache: Preserves the generated solution paths so hints can guide the player.
 */
class LevelGenerator {

    /**
     * Generates a puzzle level for the given [levelId].
     */
    fun generate(levelId: Int): Level = generateLevel(levelId)

    companion object {

        private val solutionCache = mutableMapOf<Int, Map<FlowColor, List<Point>>>()

        /**
         * Generates a guaranteed-solvable [Level] for the specified [levelId].
         */
        fun generateLevel(levelId: Int): Level {
            val safeId = maxOf(1, levelId)
            val gridSize = getGridSize(safeId)
            val seed = safeId.toLong() * 31L + 1337L
            val random = Random(seed)

            val numColors = getNumColors(safeId, random)
            val (chapterName, chapterIndex) = getChapter(safeId)

            val paths = generatePaths(gridSize, numColors, random)

            // Map paths to colors and build endpoints
            val availableColors = FlowColor.entries.take(numColors)
            val endpoints = mutableListOf<Pair<Point, FlowColor>>()
            val solutionMap = mutableMapOf<FlowColor, List<Point>>()

            for (i in 0 until numColors) {
                val color = availableColors[i]
                val path = paths[i]
                endpoints.add(Pair(path.first(), color))
                endpoints.add(Pair(path.last(), color))
                solutionMap[color] = path
            }

            // Cache solution paths for hint system
            solutionCache[safeId] = solutionMap

            return Level(
                id = safeId,
                gridSize = gridSize,
                endpoints = endpoints,
                chapter = chapterName,
                chapterIndex = chapterIndex,
                isUnlocked = (safeId == 1),
                bestMoves = null
            )
        }

        /**
         * Returns the solution paths for a given level if cached, or generates them deterministically.
         */
        fun getSolution(levelId: Int): Map<FlowColor, List<Point>> {
            val safeId = maxOf(1, levelId)
            return solutionCache[safeId] ?: run {
                generateLevel(safeId)
                solutionCache[safeId] ?: emptyMap()
            }
        }

        /**
         * Determines the square grid dimensions based on the difficulty progression curve:
         * - Levels 1-12: 5x5
         * - Levels 13-24: 6x6
         * - Levels 25-40: 7x7
         * - Levels 41-60: 8x8
         * - Levels 61-100: 9x9
         * - Levels 101-200: 10x10
         * - Levels 201+: min(12, 5 + levelId / 50)
         */
        fun getGridSize(levelId: Int): Int = when {
            levelId in 1..12 -> 5
            levelId in 13..24 -> 6
            levelId in 25..40 -> 7
            levelId in 41..60 -> 8
            levelId in 61..100 -> 9
            levelId in 101..200 -> 10
            else -> minOf(12, 5 + levelId / 50)
        }

        /**
         * Returns the minimum and maximum allowable flow colors for a given level.
         */
        fun getColorRange(levelId: Int): Pair<Int, Int> = when {
            levelId in 1..6 -> 3 to 3
            levelId in 7..12 -> 3 to 4
            levelId in 13..18 -> 4 to 5
            levelId in 19..24 -> 5 to 5
            levelId in 25..30 -> 5 to 6
            levelId in 31..40 -> 6 to 7
            levelId in 41..60 -> 7 to 8
            levelId in 61..200 -> 8 to 8
            else -> {
                val target = minOf(8, 3 + levelId / 30)
                target to target
            }
        }

        /**
         * Determines the exact number of flow colors for [levelId], bounded by 8 (FlowColor.entries.size).
         */
        fun getNumColors(levelId: Int, random: Random? = null): Int {
            val (minC, maxC) = getColorRange(levelId)
            if (minC == maxC) return minC
            val rng = random ?: Random(seed = levelId.toLong() * 31L + 1337L)
            return rng.nextInt(minC, maxC + 1)
        }

        /**
         * Returns the chapter name and 0-based chapter index for [levelId].
         */
        fun getChapter(levelId: Int): Pair<String, Int> = when {
            levelId in 1..6 -> "Calm" to 0
            levelId in 7..12 -> "Flow" to 1
            levelId in 13..18 -> "Bloom" to 2
            levelId in 19..24 -> "Glow" to 3
            levelId in 25..30 -> "Zen" to 4
            levelId in 31..50 -> "Dawn" to 5
            levelId in 51..75 -> "Mist" to 6
            levelId in 76..100 -> "Aura" to 7
            levelId in 101..150 -> "Nova" to 8
            levelId in 151..200 -> "Void" to 9
            else -> "Infinity" to 10
        }

        fun getChapterName(levelId: Int): String = getChapter(levelId).first

        fun getChapterIndex(levelId: Int): Int = getChapter(levelId).second

        /**
         * Generates [targetColors] disjoint simple paths that cover all cells of a [gridSize] x [gridSize] board.
         */
        private fun generatePaths(
            gridSize: Int,
            targetColors: Int,
            random: Random
        ): List<List<Point>> {
            val maxAttempts = 150

            for (attempt in 0 until maxAttempts) {
                val candidatePaths = attemptRandomWalkPartition(gridSize, targetColors, random)
                if (candidatePaths != null &&
                    candidatePaths.size == targetColors &&
                    validatePaths(candidatePaths, gridSize)
                ) {
                    return candidatePaths
                }
            }

            // Guaranteed mathematical fallback
            return generateSerpentinePaths(gridSize, targetColors, random)
        }

        /**
         * Attempts to partition the grid using random walk exploration followed by
         * singleton absorption, path merging, and path splitting.
         */
        private fun attemptRandomWalkPartition(
            gridSize: Int,
            targetColors: Int,
            random: Random
        ): List<List<Point>>? {
            val totalCells = gridSize * gridSize
            val visited = BooleanArray(totalCells)
            val paths = mutableListOf<MutableList<Point>>()

            fun toPoint(index: Int) = Point(index / gridSize, index % gridSize)
            fun toIndex(p: Point) = p.row * gridSize + p.col

            fun getUnvisitedNeighbors(p: Point): List<Point> {
                val nbs = mutableListOf<Point>()
                if (p.row > 0) nbs.add(Point(p.row - 1, p.col))
                if (p.row < gridSize - 1) nbs.add(Point(p.row + 1, p.col))
                if (p.col > 0) nbs.add(Point(p.row, p.col - 1))
                if (p.col < gridSize - 1) nbs.add(Point(p.row, p.col + 1))
                return nbs.filter { !visited[toIndex(it)] }
            }

            val targetAvgLen = maxOf(2, totalCells / targetColors)
            val unvisitedIndices = (0 until totalCells).toMutableList()

            // 1. Initial random walks across the grid
            while (unvisitedIndices.isNotEmpty()) {
                // Bias starting cell toward cells with fewer unvisited neighbors (Warnsdorff heuristic)
                unvisitedIndices.shuffle(random)
                val startIdx = unvisitedIndices.minByOrNull { idx ->
                    getUnvisitedNeighbors(toPoint(idx)).size
                } ?: unvisitedIndices.removeAt(unvisitedIndices.lastIndex)

                unvisitedIndices.remove(startIdx)
                if (visited[startIdx]) continue

                visited[startIdx] = true
                val currentPath = mutableListOf(toPoint(startIdx))
                var current = toPoint(startIdx)

                val walkLimit = random.nextInt(maxOf(2, targetAvgLen - 2), targetAvgLen + 5)

                while (currentPath.size < walkLimit) {
                    val unvisitedNbs = getUnvisitedNeighbors(current)
                    if (unvisitedNbs.isEmpty()) break

                    // Pick neighbor with fewest remaining unvisited neighbors
                    val next = unvisitedNbs.minByOrNull { nb ->
                        getUnvisitedNeighbors(nb).size + random.nextDouble() * 0.4
                    } ?: unvisitedNbs.random(random)

                    val nextIdx = toIndex(next)
                    visited[nextIdx] = true
                    unvisitedIndices.remove(nextIdx)
                    currentPath.add(next)
                    current = next
                }

                paths.add(currentPath)
            }

            // 2. Absorb any 1-cell paths (singletons) into adjacent paths
            if (!absorbSingletons(paths, gridSize, random)) {
                return null
            }

            // 3. If paths.size > targetColors, merge paths whose endpoints touch
            var mergeAttempts = 0
            val maxMergeAttempts = 300
            while (paths.size > targetColors && mergeAttempts < maxMergeAttempts) {
                mergeAttempts++
                val merged = tryMergeTwoPaths(paths, random)
                if (!merged) break
            }

            // 4. If paths.size < targetColors, split paths of length >= 4 into two paths of length >= 2
            var splitAttempts = 0
            val maxSplitAttempts = 100
            while (paths.size < targetColors && splitAttempts < maxSplitAttempts) {
                splitAttempts++
                val splittable = paths.filter { it.size >= 4 }
                if (splittable.isEmpty()) break
                val pathToSplit = splittable.maxByOrNull { it.size } ?: break
                val splitIdx = random.nextInt(2, pathToSplit.size - 1)
                val p1 = pathToSplit.subList(0, splitIdx).toMutableList()
                val p2 = pathToSplit.subList(splitIdx, pathToSplit.size).toMutableList()
                paths.remove(pathToSplit)
                paths.add(p1)
                paths.add(p2)
            }

            if (paths.size != targetColors) return null

            return paths
        }

        /**
         * Absorbs isolated 1-cell paths into neighboring paths by attaching to ends or inserting
         * between adjacent consecutive steps.
         */
        private fun absorbSingletons(
            paths: MutableList<MutableList<Point>>,
            gridSize: Int,
            random: Random
        ): Boolean {
            var safetyIterations = 0
            while (paths.any { it.size == 1 } && safetyIterations < 60) {
                safetyIterations++
                val singleIdx = paths.indexOfFirst { it.size == 1 }
                if (singleIdx == -1) break
                val singlePoint = paths[singleIdx][0]

                var absorbed = false
                val neighborPoints = listOf(
                    Point(singlePoint.row - 1, singlePoint.col),
                    Point(singlePoint.row + 1, singlePoint.col),
                    Point(singlePoint.row, singlePoint.col - 1),
                    Point(singlePoint.row, singlePoint.col + 1)
                ).filter { it.row in 0 until gridSize && it.col in 0 until gridSize }
                    .shuffled(random)

                for (nb in neighborPoints) {
                    val ownerIdx = paths.indexOfFirst { it.contains(nb) }
                    if (ownerIdx == -1 || ownerIdx == singleIdx) continue
                    val ownerPath = paths[ownerIdx]

                    if (ownerPath.first() == nb) {
                        ownerPath.add(0, singlePoint)
                        paths.removeAt(singleIdx)
                        absorbed = true
                        break
                    } else if (ownerPath.last() == nb) {
                        ownerPath.add(singlePoint)
                        paths.removeAt(singleIdx)
                        absorbed = true
                        break
                    } else {
                        val idx = ownerPath.indexOf(nb)
                        if (idx > 0 && singlePoint.isAdjacentTo(ownerPath[idx - 1])) {
                            ownerPath.add(idx, singlePoint)
                            paths.removeAt(singleIdx)
                            absorbed = true
                            break
                        } else if (idx < ownerPath.lastIndex && singlePoint.isAdjacentTo(ownerPath[idx + 1])) {
                            ownerPath.add(idx + 1, singlePoint)
                            paths.removeAt(singleIdx)
                            absorbed = true
                            break
                        }
                    }
                }

                if (!absorbed) return false
            }

            return paths.all { it.size >= 2 }
        }

        /**
         * Merges two distinct paths whose endpoints are orthogonally adjacent.
         */
        private fun tryMergeTwoPaths(
            paths: MutableList<MutableList<Point>>,
            random: Random
        ): Boolean {
            val indices = paths.indices.shuffled(random)
            for (i in indices) {
                val pathA = paths[i]
                for (j in indices) {
                    if (i == j) continue
                    val pathB = paths[j]

                    val aFirst = pathA.first()
                    val aLast = pathA.last()
                    val bFirst = pathB.first()
                    val bLast = pathB.last()

                    when {
                        aLast.isAdjacentTo(bFirst) -> {
                            pathA.addAll(pathB)
                            paths.removeAt(j)
                            return true
                        }
                        aLast.isAdjacentTo(bLast) -> {
                            pathA.addAll(pathB.reversed())
                            paths.removeAt(j)
                            return true
                        }
                        aFirst.isAdjacentTo(bLast) -> {
                            val merged = pathB.toMutableList()
                            merged.addAll(pathA)
                            paths[i] = merged
                            paths.removeAt(j)
                            return true
                        }
                        aFirst.isAdjacentTo(bFirst) -> {
                            val merged = pathA.reversed().toMutableList()
                            merged.addAll(pathB)
                            paths[i] = merged
                            paths.removeAt(j)
                            return true
                        }
                    }
                }
            }
            return false
        }

        /**
         * Fallback generator that partitions a Hamiltonian serpentine path across the grid
         * into [targetColors] segments, guaranteeing 100% board fill and valid simple paths.
         */
        private fun generateSerpentinePaths(
            gridSize: Int,
            targetColors: Int,
            random: Random
        ): List<List<Point>> {
            val totalCells = gridSize * gridSize
            val allCells = mutableListOf<Point>()

            val invertRows = random.nextBoolean()
            val rowRange = if (invertRows) gridSize - 1 downTo 0 else 0 until gridSize

            for (r in rowRange) {
                val reverseCols = (r % 2 == 1)
                val colRange = if (reverseCols) gridSize - 1 downTo 0 else 0 until gridSize
                for (c in colRange) {
                    allCells.add(Point(r, c))
                }
            }

            // Distribute cells across targetColors paths, each having at least 2 cells
            val segmentLengths = IntArray(targetColors) { 2 }
            var remaining = totalCells - targetColors * 2

            while (remaining > 0) {
                val idx = random.nextInt(targetColors)
                segmentLengths[idx]++
                remaining--
            }

            val paths = mutableListOf<List<Point>>()
            var offset = 0
            for (len in segmentLengths) {
                paths.add(allCells.subList(offset, offset + len))
                offset += len
            }

            return paths
        }

        /**
         * Validates that the paths form a valid, solvable Flow puzzle:
         * 1. Every path has at least 2 cells.
         * 2. All consecutive cells in each path are orthogonally adjacent.
         * 3. Total cells across all paths equal gridSize * gridSize (100% coverage).
         * 4. No cells overlap or are repeated.
         */
        fun validatePaths(paths: List<List<Point>>, gridSize: Int): Boolean {
            val totalCells = gridSize * gridSize
            val visitedPoints = mutableSetOf<Point>()

            for (path in paths) {
                if (path.size < 2) return false
                for (i in 0 until path.size - 1) {
                    if (!path[i].isAdjacentTo(path[i + 1])) return false
                }
                for (p in path) {
                    if (p.row !in 0 until gridSize || p.col !in 0 until gridSize) return false
                    if (!visitedPoints.add(p)) return false
                }
            }

            return visitedPoints.size == totalCells
        }
    }
}
