package com.zenflow.game.game.engine

import com.zenflow.game.game.model.Cell
import com.zenflow.game.game.model.FlowColor
import com.zenflow.game.game.model.GameState
import com.zenflow.game.game.model.Level
import com.zenflow.game.game.model.Point
import kotlin.math.abs

/**
 * Core game engine for ZenFlow.
 * Manages grid layout, path drawing, move validation, overlap clearing,
 * backtracking, and win condition checks.
 */
class PuzzleEngine(private val level: Level) {

    private var state: GameState = GameState.fromLevel(level)

    // Lookup map of endpoints: Point -> FlowColor
    private val endpointMap: Map<Point, FlowColor> = level.endpoints.toMap()

    // Endpoints grouped by color
    private val colorEndpoints: Map<FlowColor, List<Point>> =
        level.endpoints.groupBy({ it.second }, { it.first })

    // Undo stack storing previous path snapshots
    private val undoStack = mutableListOf<Map<FlowColor, List<Point>>>()
    private val maxUndoSize = 50

    // Store the solution if we have one (for generated levels)
    private var solutionPaths: Map<FlowColor, List<Point>>? = null

    /**
     * Returns the current snapshot of the GameState.
     */
    fun getState(): GameState = state

    /**
     * Resets the current level back to its initial unsolved state.
     */
    fun resetLevel(): GameState {
        undoStack.clear()
        state = GameState.fromLevel(level)
        return state
    }

    /**
     * Toggles or sets the paused status of the game session.
     */
    fun setPaused(paused: Boolean): GameState {
        state = state.copy(isPaused = paused)
        return state
    }

    /**
     * Checks if the flow for a given color is completely and validly connected between its two endpoints.
     */
    fun isFlowConnected(color: FlowColor): Boolean {
        val path = state.paths[color] ?: return false
        if (path.size < 2) return false
        val endpoints = colorEndpoints[color] ?: return false
        if (endpoints.size != 2) return false
        val ep1 = endpoints[0]
        val ep2 = endpoints[1]
        val first = path.first()
        val last = path.last()
        return (first == ep1 && last == ep2) || (first == ep2 && last == ep1)
    }

    /**
     * Returns the set of all colors whose flows are currently completed.
     */
    fun getConnectedColors(): Set<FlowColor> =
        level.colors.filter { isFlowConnected(it) }.toSet()

    /**
     * Deep copies the current paths snapshot and pushes it to the undo stack,
     * maintaining the maximum stack depth of [maxUndoSize].
     */
    fun saveUndoState() {
        val snapshot = state.paths.mapValues { (_, points) -> points.toList() }
        undoStack.add(snapshot)
        while (undoStack.size > maxUndoSize) {
            undoStack.removeAt(0)
        }
    }

    /**
     * Restores the previous path configuration from the undo stack,
     * rebuilding the board grid and updating completion metrics.
     */
    fun undo(): GameState {
        if (undoStack.isEmpty()) return state

        val previousPaths = undoStack.removeAt(undoStack.lastIndex)
        val newGrid = rebuildGrid(previousPaths)

        state = state.copy(
            grid = newGrid,
            paths = previousPaths,
            currentDrawingColor = null
        )
        val completed = checkCompletion()
        val percent = calculateCompletionPercent()
        state = state.copy(
            isCompleted = completed,
            completionPercent = percent
        )
        return state
    }

    /**
     * Returns true if there is at least one previous move recorded on the undo stack.
     */
    fun canUndo(): Boolean = undoStack.isNotEmpty()

    /**
     * Sets the pre-calculated solution paths for the current level to enable hints.
     */
    fun setSolution(solution: Map<FlowColor, List<Point>>) {
        solutionPaths = solution
    }

    /**
     * Returns the color of a flow that is NOT yet correctly connected.
     * Prioritizes flows that haven't been started.
     * Returns null if all flows are connected or no solution available.
     */
    fun getHint(): FlowColor? {
        val solution = solutionPaths ?: return null
        val unconnectedColors = level.colors.filter { color ->
            solution.containsKey(color) && !isFlowConnected(color)
        }
        if (unconnectedColors.isEmpty()) return null

        // Prioritize flows that haven't been started (no path drawn yet or only touched endpoint)
        return unconnectedColors.firstOrNull { color ->
            state.paths[color].isNullOrEmpty()
        } ?: unconnectedColors.firstOrNull { color ->
            state.paths[color]?.size == 1
        } ?: unconnectedColors.first()
    }

    /**
     * Gets a hint color and applies its complete solution path to the grid.
     * Clears conflicting segments of any intersecting paths and recalculates level completion.
     * Returns updated GameState.
     */
    fun applyHint(): GameState {
        val hintColor = getHint() ?: return state
        val solution = solutionPaths ?: return state
        val hintPath = solution[hintColor] ?: return state

        saveUndoState()

        val newPaths = state.paths.toMutableMap()
        val hintPointSet = hintPath.toSet()

        // Truncate conflicting paths of other colors that cross the hint path
        for ((otherColor, otherPath) in newPaths.toMap()) {
            if (otherColor != hintColor) {
                val conflictIndex = otherPath.indexOfFirst { it in hintPointSet }
                if (conflictIndex >= 0) {
                    newPaths[otherColor] = otherPath.subList(0, conflictIndex)
                }
            }
        }

        newPaths[hintColor] = hintPath.toList()

        val newGrid = rebuildGrid(newPaths)
        val newMoveCount = state.moveCount + 1
        state = state.copy(
            grid = newGrid,
            paths = newPaths,
            currentDrawingColor = null,
            moveCount = newMoveCount
        )
        val completed = checkCompletion()
        val percent = calculateCompletionPercent()
        state = state.copy(
            isCompleted = completed,
            completionPercent = percent
        )
        return state
    }

    /**
     * Handles touch start / finger down event on the board.
     *
     * - Touching an endpoint starts drawing a path of that color (clearing any previous path).
     * - Touching an existing path clears the path from that point forward and resumes drawing.
     * - Touching an empty cell does nothing.
     */
    fun onTouchStart(row: Int, col: Int): GameState {
        if (!isInBounds(row, col)) return state

        saveUndoState()

        val touchedPoint = Point(row, col)
        val endpointColor = endpointMap[touchedPoint]
        val newPaths = state.paths.toMutableMap()
        var newDrawingColor: FlowColor? = null
        var moveInitiated = false

        if (endpointColor != null) {
            // Case 1: Touched an endpoint -> Start fresh path from this endpoint
            newDrawingColor = endpointColor
            newPaths[endpointColor] = listOf(touchedPoint)
            moveInitiated = true
        } else {
            // Case 2: Check if touched on an existing path of any color
            val entry = newPaths.entries.find { it.value.contains(touchedPoint) }
            if (entry != null) {
                val color = entry.key
                val currentPath = entry.value
                val index = currentPath.indexOf(touchedPoint)
                if (index >= 0) {
                    // Truncate path from that point forward and continue drawing from this point
                    newDrawingColor = color
                    newPaths[color] = currentPath.subList(0, index + 1)
                    moveInitiated = true
                }
            }
        }

        if (moveInitiated) {
            val newGrid = rebuildGrid(newPaths)
            val newMoveCount = state.moveCount + 1
            state = state.copy(
                grid = newGrid,
                paths = newPaths,
                currentDrawingColor = newDrawingColor,
                moveCount = newMoveCount
            )
            val completed = checkCompletion()
            val percent = calculateCompletionPercent()
            state = state.copy(
                isCompleted = completed,
                completionPercent = percent
            )
        } else {
            // If no move was actually initiated, discard the undo snapshot
            if (undoStack.isNotEmpty()) {
                undoStack.removeAt(undoStack.lastIndex)
            }
            state = state.copy(currentDrawingColor = null)
        }

        return state
    }

    /**
     * Handles finger drag event.
     *
     * Steps orthogonally from the path's head towards the target point:
     * - Backtracks if moving over points already in the current path.
     * - Blocks moving onto another color's endpoint.
     * - Stops at the matching endpoint to complete the flow.
     * - Clears conflicting segments of another color's path if intersected.
     */
    fun onTouchMove(row: Int, col: Int): GameState {
        val color = state.currentDrawingColor ?: return state
        if (!isInBounds(row, col)) return state

        val targetPoint = Point(row, col)
        val currentPath = state.paths[color]?.toMutableList() ?: return state
        if (currentPath.isEmpty()) return state

        val head = currentPath.last()
        if (head == targetPoint) return state

        val steps = getSteps(head, targetPoint)
        if (steps.isEmpty()) return state

        val newPaths = state.paths.toMutableMap()
        var pathModified = false

        for (step in steps) {
            val currHead = currentPath.last()
            if (!isAdjacent(currHead, step)) break

            // Backtracking: if step is already in currentPath, truncate to that point
            if (currentPath.contains(step)) {
                val idx = currentPath.indexOf(step)
                if (idx < currentPath.lastIndex) {
                    currentPath.subList(idx + 1, currentPath.size).clear()
                    pathModified = true
                }
                continue
            }

            // If the flow is already complete (head reached matching endpoint), do not extend further
            if (isPathComplete(color, currentPath)) {
                break
            }

            val stepEndpointColor = endpointMap[step]

            // Cannot cross or enter an endpoint of a different color
            if (stepEndpointColor != null && stepEndpointColor != color) {
                break
            }

            // If entering another color's path, clear that color's path from the collision point forward
            for ((otherColor, otherPath) in newPaths) {
                if (otherColor != color && otherPath.contains(step)) {
                    val cutIndex = otherPath.indexOf(step)
                    if (cutIndex >= 0) {
                        newPaths[otherColor] = otherPath.subList(0, cutIndex)
                        pathModified = true
                    }
                }
            }

            // Extend path with step
            currentPath.add(step)
            pathModified = true

            // If we just reached the matching endpoint, flow is complete!
            if (stepEndpointColor == color) {
                break
            }
        }

        if (pathModified) {
            newPaths[color] = currentPath
            val newGrid = rebuildGrid(newPaths)
            state = state.copy(
                grid = newGrid,
                paths = newPaths
            )
            val completed = checkCompletion()
            val percent = calculateCompletionPercent()
            state = state.copy(
                isCompleted = completed,
                completionPercent = percent
            )
        }

        return state
    }

    /**
     * Handles touch release / finger up event.
     * Finalizes current drawing operation and checks for level completion.
     */
    fun onTouchEnd(): GameState {
        val completed = checkCompletion()
        val percent = calculateCompletionPercent()
        state = state.copy(
            currentDrawingColor = null,
            isCompleted = completed,
            completionPercent = percent
        )
        return state
    }

    /**
     * Returns true if [a] and [b] are horizontally or vertically adjacent.
     * Diagonal neighbors return false.
     */
    private fun isAdjacent(a: Point, b: Point): Boolean {
        val dRow = abs(a.row - b.row)
        val dCol = abs(a.col - b.col)
        return (dRow == 1 && dCol == 0) || (dRow == 0 && dCol == 1)
    }

    /**
     * Validates if the level is fully completed:
     * 1. All colored endpoint pairs are properly connected.
     * 2. All cells in the grid are filled by a path.
     */
    private fun checkCompletion(): Boolean {
        val allFlowsConnected = level.colors.all { isFlowConnected(it) }
        if (!allFlowsConnected) return false

        // Check if every cell in the grid is traversed by a path
        return state.grid.all { row ->
            row.all { cell -> cell.pathColor != null }
        }
    }

    /**
     * Calculates the completion percentage (0.0f to 1.0f) based on cells filled by paths.
     */
    private fun calculateCompletionPercent(): Float {
        val totalCells = level.gridSize * level.gridSize
        if (totalCells == 0) return 0f
        val filledCells = state.grid.sumOf { row ->
            row.count { it.pathColor != null }
        }
        return filledCells.toFloat() / totalCells.toFloat()
    }

    /**
     * Checks if a specific path has reached both endpoints of its color.
     */
    private fun isPathComplete(color: FlowColor, path: List<Point>): Boolean {
        if (path.size < 2) return false
        val endpoints = colorEndpoints[color] ?: return false
        if (endpoints.size != 2) return false
        val ep1 = endpoints[0]
        val ep2 = endpoints[1]
        val first = path.first()
        val last = path.last()
        return (first == ep1 && last == ep2) || (first == ep2 && last == ep1)
    }

    /**
     * Decomposes a drag vector between [from] and [to] into a sequence of orthogonal single steps.
     */
    private fun getSteps(from: Point, to: Point): List<Point> {
        val steps = mutableListOf<Point>()
        var curr = from
        val maxSteps = level.gridSize * 2
        var iterations = 0

        while (curr != to && iterations < maxSteps) {
            iterations++
            val dRow = to.row - curr.row
            val dCol = to.col - curr.col

            val next = when {
                abs(dRow) >= abs(dCol) && dRow != 0 -> {
                    Point(curr.row + if (dRow > 0) 1 else -1, curr.col)
                }
                dCol != 0 -> {
                    Point(curr.row, curr.col + if (dCol > 0) 1 else -1)
                }
                else -> to
            }

            if (next == curr) break
            steps.add(next)
            curr = next
        }

        return steps
    }

    /**
     * Rebuilds the 2D array of [Cell]s according to the level endpoints and active paths.
     */
    private fun rebuildGrid(paths: Map<FlowColor, List<Point>>): Array<Array<Cell>> {
        val pathCellMap = mutableMapOf<Point, FlowColor>()
        for ((color, points) in paths) {
            for (pt in points) {
                pathCellMap[pt] = color
            }
        }

        return Array(level.gridSize) { r ->
            Array(level.gridSize) { c ->
                val point = Point(r, c)
                val epColor = endpointMap[point]
                val pColor = pathCellMap[point]

                if (epColor != null) {
                    val isPartOfOwnPath = paths[epColor]?.contains(point) == true || pColor == epColor
                    Cell(
                        position = point,
                        isEndpoint = true,
                        color = epColor,
                        pathColor = if (isPartOfOwnPath) epColor else null
                    )
                } else {
                    Cell(
                        position = point,
                        isEndpoint = false,
                        color = pColor,
                        pathColor = pColor
                    )
                }
            }
        }
    }

    private fun isInBounds(row: Int, col: Int): Boolean =
        row in 0 until level.gridSize && col in 0 until level.gridSize
}
