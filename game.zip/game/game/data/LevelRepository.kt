package com.zenflow.game.game.data

import com.zenflow.game.game.model.FlowColor
import com.zenflow.game.game.model.Level
import com.zenflow.game.game.model.Point

/**
 * Repository containing all 30 predefined, verified solvable levels for ZenFlow.
 * Puzzles span 5 chapters: Calm (5x5), Flow (6x6), Bloom (7x7), Glow (7x7), and Zen (8x8).
 */
class LevelRepository {

    fun getLevels(): List<Level> = Companion.getLevels()

    fun getLevel(id: Int): Level? = Companion.getLevel(id)

    fun getChapters(): List<String> = Companion.getChapters()

    fun getLevelsByChapter(chapter: String): List<Level> = Companion.getLevelsByChapter(chapter)

    companion object {
        private val chapters: List<String> = listOf("Calm", "Flow", "Bloom", "Glow", "Zen")

        private val levels: List<Level> = listOf(
            Level(
                id = 1,
                gridSize = 5,
                endpoints = listOf(
                    Pair(Point(0, 0), FlowColor.RED), Pair(Point(0, 4), FlowColor.RED),
                    Pair(Point(1, 1), FlowColor.BLUE), Pair(Point(4, 0), FlowColor.BLUE),
                    Pair(Point(0, 3), FlowColor.GREEN), Pair(Point(3, 2), FlowColor.GREEN)
                ),
                chapter = "Calm",
                chapterIndex = 0,
                isUnlocked = true
            ),
            Level(
                id = 2,
                gridSize = 5,
                endpoints = listOf(
                    Pair(Point(1, 2), FlowColor.RED), Pair(Point(2, 4), FlowColor.RED),
                    Pair(Point(2, 2), FlowColor.BLUE), Pair(Point(4, 4), FlowColor.BLUE),
                    Pair(Point(0, 4), FlowColor.GREEN), Pair(Point(1, 4), FlowColor.GREEN)
                ),
                chapter = "Calm",
                chapterIndex = 0,
                isUnlocked = false
            ),
            Level(
                id = 3,
                gridSize = 5,
                endpoints = listOf(
                    Pair(Point(3, 1), FlowColor.RED), Pair(Point(4, 3), FlowColor.RED),
                    Pair(Point(0, 4), FlowColor.BLUE), Pair(Point(3, 3), FlowColor.BLUE),
                    Pair(Point(1, 1), FlowColor.GREEN), Pair(Point(1, 4), FlowColor.GREEN)
                ),
                chapter = "Calm",
                chapterIndex = 0,
                isUnlocked = false
            ),
            Level(
                id = 4,
                gridSize = 5,
                endpoints = listOf(
                    Pair(Point(2, 1), FlowColor.RED), Pair(Point(2, 2), FlowColor.RED),
                    Pair(Point(0, 3), FlowColor.BLUE), Pair(Point(4, 0), FlowColor.BLUE),
                    Pair(Point(0, 0), FlowColor.GREEN), Pair(Point(3, 1), FlowColor.GREEN),
                    Pair(Point(1, 1), FlowColor.YELLOW), Pair(Point(3, 0), FlowColor.YELLOW)
                ),
                chapter = "Calm",
                chapterIndex = 0,
                isUnlocked = false
            ),
            Level(
                id = 5,
                gridSize = 5,
                endpoints = listOf(
                    Pair(Point(3, 2), FlowColor.RED), Pair(Point(4, 4), FlowColor.RED),
                    Pair(Point(2, 2), FlowColor.BLUE), Pair(Point(4, 2), FlowColor.BLUE),
                    Pair(Point(0, 0), FlowColor.GREEN), Pair(Point(0, 4), FlowColor.GREEN),
                    Pair(Point(1, 0), FlowColor.YELLOW), Pair(Point(4, 1), FlowColor.YELLOW)
                ),
                chapter = "Calm",
                chapterIndex = 0,
                isUnlocked = false
            ),
            Level(
                id = 6,
                gridSize = 5,
                endpoints = listOf(
                    Pair(Point(1, 3), FlowColor.RED), Pair(Point(2, 1), FlowColor.RED),
                    Pair(Point(0, 0), FlowColor.BLUE), Pair(Point(2, 0), FlowColor.BLUE),
                    Pair(Point(0, 1), FlowColor.GREEN), Pair(Point(2, 2), FlowColor.GREEN),
                    Pair(Point(0, 2), FlowColor.YELLOW), Pair(Point(3, 0), FlowColor.YELLOW)
                ),
                chapter = "Calm",
                chapterIndex = 0,
                isUnlocked = false
            ),
            Level(
                id = 7,
                gridSize = 6,
                endpoints = listOf(
                    Pair(Point(0, 5), FlowColor.RED), Pair(Point(2, 4), FlowColor.RED),
                    Pair(Point(0, 2), FlowColor.BLUE), Pair(Point(3, 4), FlowColor.BLUE),
                    Pair(Point(0, 1), FlowColor.GREEN), Pair(Point(1, 4), FlowColor.GREEN),
                    Pair(Point(1, 1), FlowColor.YELLOW), Pair(Point(4, 4), FlowColor.YELLOW)
                ),
                chapter = "Flow",
                chapterIndex = 1,
                isUnlocked = false
            ),
            Level(
                id = 8,
                gridSize = 6,
                endpoints = listOf(
                    Pair(Point(1, 0), FlowColor.RED), Pair(Point(4, 4), FlowColor.RED),
                    Pair(Point(1, 1), FlowColor.BLUE), Pair(Point(5, 0), FlowColor.BLUE),
                    Pair(Point(2, 5), FlowColor.GREEN), Pair(Point(4, 2), FlowColor.GREEN),
                    Pair(Point(1, 4), FlowColor.YELLOW), Pair(Point(5, 5), FlowColor.YELLOW)
                ),
                chapter = "Flow",
                chapterIndex = 1,
                isUnlocked = false
            ),
            Level(
                id = 9,
                gridSize = 6,
                endpoints = listOf(
                    Pair(Point(2, 4), FlowColor.RED), Pair(Point(5, 5), FlowColor.RED),
                    Pair(Point(0, 4), FlowColor.BLUE), Pair(Point(3, 4), FlowColor.BLUE),
                    Pair(Point(1, 4), FlowColor.GREEN), Pair(Point(5, 4), FlowColor.GREEN),
                    Pair(Point(1, 1), FlowColor.YELLOW), Pair(Point(4, 1), FlowColor.YELLOW),
                    Pair(Point(1, 2), FlowColor.PURPLE), Pair(Point(4, 2), FlowColor.PURPLE)
                ),
                chapter = "Flow",
                chapterIndex = 1,
                isUnlocked = false
            ),
            Level(
                id = 10,
                gridSize = 6,
                endpoints = listOf(
                    Pair(Point(1, 5), FlowColor.RED), Pair(Point(4, 3), FlowColor.RED),
                    Pair(Point(1, 2), FlowColor.BLUE), Pair(Point(4, 4), FlowColor.BLUE),
                    Pair(Point(0, 0), FlowColor.GREEN), Pair(Point(5, 2), FlowColor.GREEN),
                    Pair(Point(2, 3), FlowColor.YELLOW), Pair(Point(5, 3), FlowColor.YELLOW),
                    Pair(Point(0, 4), FlowColor.PURPLE), Pair(Point(0, 5), FlowColor.PURPLE)
                ),
                chapter = "Flow",
                chapterIndex = 1,
                isUnlocked = false
            ),
            Level(
                id = 11,
                gridSize = 6,
                endpoints = listOf(
                    Pair(Point(3, 0), FlowColor.RED), Pair(Point(5, 0), FlowColor.RED),
                    Pair(Point(0, 2), FlowColor.BLUE), Pair(Point(0, 3), FlowColor.BLUE),
                    Pair(Point(0, 0), FlowColor.GREEN), Pair(Point(0, 4), FlowColor.GREEN),
                    Pair(Point(0, 5), FlowColor.YELLOW), Pair(Point(1, 0), FlowColor.YELLOW),
                    Pair(Point(4, 0), FlowColor.PURPLE), Pair(Point(4, 4), FlowColor.PURPLE)
                ),
                chapter = "Flow",
                chapterIndex = 1,
                isUnlocked = false
            ),
            Level(
                id = 12,
                gridSize = 6,
                endpoints = listOf(
                    Pair(Point(1, 4), FlowColor.RED), Pair(Point(5, 1), FlowColor.RED),
                    Pair(Point(0, 0), FlowColor.BLUE), Pair(Point(5, 0), FlowColor.BLUE),
                    Pair(Point(2, 4), FlowColor.GREEN), Pair(Point(4, 4), FlowColor.GREEN),
                    Pair(Point(0, 2), FlowColor.YELLOW), Pair(Point(5, 2), FlowColor.YELLOW),
                    Pair(Point(1, 0), FlowColor.PURPLE), Pair(Point(2, 1), FlowColor.PURPLE)
                ),
                chapter = "Flow",
                chapterIndex = 1,
                isUnlocked = false
            ),
            Level(
                id = 13,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(1, 2), FlowColor.RED), Pair(Point(3, 6), FlowColor.RED),
                    Pair(Point(1, 4), FlowColor.BLUE), Pair(Point(6, 0), FlowColor.BLUE),
                    Pair(Point(5, 1), FlowColor.GREEN), Pair(Point(5, 5), FlowColor.GREEN),
                    Pair(Point(0, 2), FlowColor.YELLOW), Pair(Point(5, 0), FlowColor.YELLOW),
                    Pair(Point(0, 0), FlowColor.PURPLE), Pair(Point(3, 3), FlowColor.PURPLE)
                ),
                chapter = "Bloom",
                chapterIndex = 2,
                isUnlocked = false
            ),
            Level(
                id = 14,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(1, 1), FlowColor.RED), Pair(Point(2, 4), FlowColor.RED),
                    Pair(Point(1, 5), FlowColor.BLUE), Pair(Point(6, 6), FlowColor.BLUE),
                    Pair(Point(2, 5), FlowColor.GREEN), Pair(Point(4, 5), FlowColor.GREEN),
                    Pair(Point(0, 1), FlowColor.YELLOW), Pair(Point(4, 0), FlowColor.YELLOW),
                    Pair(Point(3, 0), FlowColor.PURPLE), Pair(Point(5, 1), FlowColor.PURPLE)
                ),
                chapter = "Bloom",
                chapterIndex = 2,
                isUnlocked = false
            ),
            Level(
                id = 15,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(0, 6), FlowColor.RED), Pair(Point(2, 2), FlowColor.RED),
                    Pair(Point(0, 2), FlowColor.BLUE), Pair(Point(0, 4), FlowColor.BLUE),
                    Pair(Point(1, 1), FlowColor.GREEN), Pair(Point(1, 6), FlowColor.GREEN),
                    Pair(Point(5, 1), FlowColor.YELLOW), Pair(Point(5, 5), FlowColor.YELLOW),
                    Pair(Point(0, 1), FlowColor.PURPLE), Pair(Point(3, 4), FlowColor.PURPLE),
                    Pair(Point(5, 2), FlowColor.ORANGE), Pair(Point(5, 4), FlowColor.ORANGE)
                ),
                chapter = "Bloom",
                chapterIndex = 2,
                isUnlocked = false
            ),
            Level(
                id = 16,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(3, 2), FlowColor.RED), Pair(Point(6, 6), FlowColor.RED),
                    Pair(Point(3, 1), FlowColor.BLUE), Pair(Point(6, 5), FlowColor.BLUE),
                    Pair(Point(1, 1), FlowColor.GREEN), Pair(Point(2, 4), FlowColor.GREEN),
                    Pair(Point(4, 1), FlowColor.YELLOW), Pair(Point(5, 1), FlowColor.YELLOW),
                    Pair(Point(4, 5), FlowColor.PURPLE), Pair(Point(5, 5), FlowColor.PURPLE),
                    Pair(Point(1, 5), FlowColor.ORANGE), Pair(Point(5, 4), FlowColor.ORANGE)
                ),
                chapter = "Bloom",
                chapterIndex = 2,
                isUnlocked = false
            ),
            Level(
                id = 17,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(3, 3), FlowColor.RED), Pair(Point(3, 5), FlowColor.RED),
                    Pair(Point(1, 2), FlowColor.BLUE), Pair(Point(6, 0), FlowColor.BLUE),
                    Pair(Point(2, 3), FlowColor.GREEN), Pair(Point(3, 2), FlowColor.GREEN),
                    Pair(Point(0, 4), FlowColor.YELLOW), Pair(Point(0, 5), FlowColor.YELLOW),
                    Pair(Point(0, 6), FlowColor.PURPLE), Pair(Point(5, 5), FlowColor.PURPLE),
                    Pair(Point(2, 4), FlowColor.ORANGE), Pair(Point(3, 6), FlowColor.ORANGE)
                ),
                chapter = "Bloom",
                chapterIndex = 2,
                isUnlocked = false
            ),
            Level(
                id = 18,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(0, 4), FlowColor.RED), Pair(Point(5, 2), FlowColor.RED),
                    Pair(Point(4, 0), FlowColor.BLUE), Pair(Point(6, 1), FlowColor.BLUE),
                    Pair(Point(1, 4), FlowColor.GREEN), Pair(Point(6, 2), FlowColor.GREEN),
                    Pair(Point(3, 0), FlowColor.YELLOW), Pair(Point(3, 3), FlowColor.YELLOW),
                    Pair(Point(0, 5), FlowColor.PURPLE), Pair(Point(6, 4), FlowColor.PURPLE),
                    Pair(Point(1, 1), FlowColor.ORANGE), Pair(Point(5, 1), FlowColor.ORANGE)
                ),
                chapter = "Bloom",
                chapterIndex = 2,
                isUnlocked = false
            ),
            Level(
                id = 19,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(3, 4), FlowColor.RED), Pair(Point(5, 1), FlowColor.RED),
                    Pair(Point(0, 1), FlowColor.BLUE), Pair(Point(5, 0), FlowColor.BLUE),
                    Pair(Point(1, 3), FlowColor.GREEN), Pair(Point(4, 5), FlowColor.GREEN),
                    Pair(Point(0, 6), FlowColor.YELLOW), Pair(Point(3, 5), FlowColor.YELLOW),
                    Pair(Point(1, 6), FlowColor.PURPLE), Pair(Point(6, 0), FlowColor.PURPLE),
                    Pair(Point(3, 3), FlowColor.ORANGE), Pair(Point(4, 4), FlowColor.ORANGE)
                ),
                chapter = "Glow",
                chapterIndex = 3,
                isUnlocked = false
            ),
            Level(
                id = 20,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(0, 0), FlowColor.RED), Pair(Point(5, 1), FlowColor.RED),
                    Pair(Point(1, 6), FlowColor.BLUE), Pair(Point(2, 5), FlowColor.BLUE),
                    Pair(Point(1, 0), FlowColor.GREEN), Pair(Point(6, 3), FlowColor.GREEN),
                    Pair(Point(0, 2), FlowColor.YELLOW), Pair(Point(6, 4), FlowColor.YELLOW),
                    Pair(Point(0, 6), FlowColor.PURPLE), Pair(Point(5, 5), FlowColor.PURPLE),
                    Pair(Point(1, 5), FlowColor.ORANGE), Pair(Point(6, 5), FlowColor.ORANGE)
                ),
                chapter = "Glow",
                chapterIndex = 3,
                isUnlocked = false
            ),
            Level(
                id = 21,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(4, 6), FlowColor.RED), Pair(Point(6, 1), FlowColor.RED),
                    Pair(Point(1, 5), FlowColor.BLUE), Pair(Point(6, 0), FlowColor.BLUE),
                    Pair(Point(0, 0), FlowColor.GREEN), Pair(Point(2, 3), FlowColor.GREEN),
                    Pair(Point(2, 6), FlowColor.YELLOW), Pair(Point(5, 5), FlowColor.YELLOW),
                    Pair(Point(0, 3), FlowColor.PURPLE), Pair(Point(3, 2), FlowColor.PURPLE),
                    Pair(Point(0, 5), FlowColor.ORANGE), Pair(Point(1, 6), FlowColor.ORANGE),
                    Pair(Point(0, 4), FlowColor.PINK), Pair(Point(2, 2), FlowColor.PINK)
                ),
                chapter = "Glow",
                chapterIndex = 3,
                isUnlocked = false
            ),
            Level(
                id = 22,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(3, 1), FlowColor.RED), Pair(Point(5, 1), FlowColor.RED),
                    Pair(Point(5, 2), FlowColor.BLUE), Pair(Point(5, 5), FlowColor.BLUE),
                    Pair(Point(4, 2), FlowColor.GREEN), Pair(Point(4, 5), FlowColor.GREEN),
                    Pair(Point(1, 1), FlowColor.YELLOW), Pair(Point(2, 6), FlowColor.YELLOW),
                    Pair(Point(0, 3), FlowColor.PURPLE), Pair(Point(1, 0), FlowColor.PURPLE),
                    Pair(Point(1, 2), FlowColor.ORANGE), Pair(Point(2, 3), FlowColor.ORANGE),
                    Pair(Point(1, 5), FlowColor.PINK), Pair(Point(2, 0), FlowColor.PINK)
                ),
                chapter = "Glow",
                chapterIndex = 3,
                isUnlocked = false
            ),
            Level(
                id = 23,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(0, 2), FlowColor.RED), Pair(Point(0, 5), FlowColor.RED),
                    Pair(Point(1, 5), FlowColor.BLUE), Pair(Point(4, 5), FlowColor.BLUE),
                    Pair(Point(1, 1), FlowColor.GREEN), Pair(Point(5, 5), FlowColor.GREEN),
                    Pair(Point(0, 6), FlowColor.YELLOW), Pair(Point(4, 6), FlowColor.YELLOW),
                    Pair(Point(5, 6), FlowColor.PURPLE), Pair(Point(6, 0), FlowColor.PURPLE),
                    Pair(Point(0, 0), FlowColor.ORANGE), Pair(Point(0, 1), FlowColor.ORANGE),
                    Pair(Point(0, 3), FlowColor.PINK), Pair(Point(3, 2), FlowColor.PINK)
                ),
                chapter = "Glow",
                chapterIndex = 3,
                isUnlocked = false
            ),
            Level(
                id = 24,
                gridSize = 7,
                endpoints = listOf(
                    Pair(Point(0, 4), FlowColor.RED), Pair(Point(0, 6), FlowColor.RED),
                    Pair(Point(1, 2), FlowColor.BLUE), Pair(Point(4, 3), FlowColor.BLUE),
                    Pair(Point(0, 3), FlowColor.GREEN), Pair(Point(1, 5), FlowColor.GREEN),
                    Pair(Point(0, 0), FlowColor.YELLOW), Pair(Point(5, 0), FlowColor.YELLOW),
                    Pair(Point(3, 1), FlowColor.PURPLE), Pair(Point(6, 0), FlowColor.PURPLE),
                    Pair(Point(1, 6), FlowColor.ORANGE), Pair(Point(6, 6), FlowColor.ORANGE),
                    Pair(Point(1, 4), FlowColor.PINK), Pair(Point(5, 3), FlowColor.PINK)
                ),
                chapter = "Glow",
                chapterIndex = 3,
                isUnlocked = false
            ),
            Level(
                id = 25,
                gridSize = 8,
                endpoints = listOf(
                    Pair(Point(4, 4), FlowColor.RED), Pair(Point(5, 3), FlowColor.RED),
                    Pair(Point(0, 7), FlowColor.BLUE), Pair(Point(4, 3), FlowColor.BLUE),
                    Pair(Point(0, 1), FlowColor.GREEN), Pair(Point(5, 5), FlowColor.GREEN),
                    Pair(Point(0, 0), FlowColor.YELLOW), Pair(Point(1, 6), FlowColor.YELLOW),
                    Pair(Point(0, 2), FlowColor.PURPLE), Pair(Point(1, 3), FlowColor.PURPLE),
                    Pair(Point(0, 4), FlowColor.ORANGE), Pair(Point(2, 3), FlowColor.ORANGE),
                    Pair(Point(3, 0), FlowColor.PINK), Pair(Point(7, 0), FlowColor.PINK)
                ),
                chapter = "Zen",
                chapterIndex = 4,
                isUnlocked = false
            ),
            Level(
                id = 26,
                gridSize = 8,
                endpoints = listOf(
                    Pair(Point(3, 7), FlowColor.RED), Pair(Point(6, 6), FlowColor.RED),
                    Pair(Point(4, 5), FlowColor.BLUE), Pair(Point(6, 7), FlowColor.BLUE),
                    Pair(Point(3, 4), FlowColor.GREEN), Pair(Point(3, 5), FlowColor.GREEN),
                    Pair(Point(2, 7), FlowColor.YELLOW), Pair(Point(7, 7), FlowColor.YELLOW),
                    Pair(Point(0, 7), FlowColor.PURPLE), Pair(Point(6, 2), FlowColor.PURPLE),
                    Pair(Point(2, 2), FlowColor.ORANGE), Pair(Point(3, 2), FlowColor.ORANGE),
                    Pair(Point(6, 0), FlowColor.PINK), Pair(Point(7, 4), FlowColor.PINK)
                ),
                chapter = "Zen",
                chapterIndex = 4,
                isUnlocked = false
            ),
            Level(
                id = 27,
                gridSize = 8,
                endpoints = listOf(
                    Pair(Point(0, 0), FlowColor.RED), Pair(Point(6, 2), FlowColor.RED),
                    Pair(Point(1, 5), FlowColor.BLUE), Pair(Point(7, 5), FlowColor.BLUE),
                    Pair(Point(3, 4), FlowColor.GREEN), Pair(Point(7, 7), FlowColor.GREEN),
                    Pair(Point(6, 5), FlowColor.YELLOW), Pair(Point(7, 6), FlowColor.YELLOW),
                    Pair(Point(1, 2), FlowColor.PURPLE), Pair(Point(7, 0), FlowColor.PURPLE),
                    Pair(Point(5, 1), FlowColor.ORANGE), Pair(Point(7, 3), FlowColor.ORANGE),
                    Pair(Point(2, 5), FlowColor.PINK), Pair(Point(6, 3), FlowColor.PINK),
                    Pair(Point(1, 1), FlowColor.CYAN), Pair(Point(3, 0), FlowColor.CYAN)
                ),
                chapter = "Zen",
                chapterIndex = 4,
                isUnlocked = false
            ),
            Level(
                id = 28,
                gridSize = 8,
                endpoints = listOf(
                    Pair(Point(1, 7), FlowColor.RED), Pair(Point(7, 2), FlowColor.RED),
                    Pair(Point(2, 6), FlowColor.BLUE), Pair(Point(6, 1), FlowColor.BLUE),
                    Pair(Point(1, 6), FlowColor.GREEN), Pair(Point(3, 3), FlowColor.GREEN),
                    Pair(Point(2, 1), FlowColor.YELLOW), Pair(Point(4, 1), FlowColor.YELLOW),
                    Pair(Point(2, 4), FlowColor.PURPLE), Pair(Point(4, 4), FlowColor.PURPLE),
                    Pair(Point(0, 0), FlowColor.ORANGE), Pair(Point(0, 1), FlowColor.ORANGE),
                    Pair(Point(0, 3), FlowColor.PINK), Pair(Point(4, 0), FlowColor.PINK),
                    Pair(Point(3, 6), FlowColor.CYAN), Pair(Point(6, 4), FlowColor.CYAN)
                ),
                chapter = "Zen",
                chapterIndex = 4,
                isUnlocked = false
            ),
            Level(
                id = 29,
                gridSize = 8,
                endpoints = listOf(
                    Pair(Point(4, 2), FlowColor.RED), Pair(Point(7, 7), FlowColor.RED),
                    Pair(Point(2, 5), FlowColor.BLUE), Pair(Point(3, 4), FlowColor.BLUE),
                    Pair(Point(0, 4), FlowColor.GREEN), Pair(Point(4, 0), FlowColor.GREEN),
                    Pair(Point(2, 2), FlowColor.YELLOW), Pair(Point(3, 2), FlowColor.YELLOW),
                    Pair(Point(0, 5), FlowColor.PURPLE), Pair(Point(6, 7), FlowColor.PURPLE),
                    Pair(Point(2, 4), FlowColor.ORANGE), Pair(Point(5, 2), FlowColor.ORANGE),
                    Pair(Point(3, 1), FlowColor.PINK), Pair(Point(3, 3), FlowColor.PINK),
                    Pair(Point(5, 0), FlowColor.CYAN), Pair(Point(6, 5), FlowColor.CYAN)
                ),
                chapter = "Zen",
                chapterIndex = 4,
                isUnlocked = false
            ),
            Level(
                id = 30,
                gridSize = 8,
                endpoints = listOf(
                    Pair(Point(2, 4), FlowColor.RED), Pair(Point(6, 6), FlowColor.RED),
                    Pair(Point(1, 3), FlowColor.BLUE), Pair(Point(7, 1), FlowColor.BLUE),
                    Pair(Point(0, 7), FlowColor.GREEN), Pair(Point(7, 6), FlowColor.GREEN),
                    Pair(Point(2, 5), FlowColor.YELLOW), Pair(Point(5, 1), FlowColor.YELLOW),
                    Pair(Point(3, 4), FlowColor.PURPLE), Pair(Point(5, 2), FlowColor.PURPLE),
                    Pair(Point(0, 6), FlowColor.ORANGE), Pair(Point(3, 0), FlowColor.ORANGE),
                    Pair(Point(2, 3), FlowColor.PINK), Pair(Point(4, 2), FlowColor.PINK),
                    Pair(Point(5, 5), FlowColor.CYAN), Pair(Point(7, 2), FlowColor.CYAN)
                ),
                chapter = "Zen",
                chapterIndex = 4,
                isUnlocked = false
            )
        )

        fun getLevels(): List<Level> = levels

        fun getLevel(id: Int): Level? = levels.find { it.id == id }

        fun getChapters(): List<String> = chapters

        fun getLevelsByChapter(chapter: String): List<Level> =
            levels.filter { it.chapter.equals(chapter, ignoreCase = true) }
    }
}
