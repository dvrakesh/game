package com.zenflow.game.game.model

/**
 * A data class representing a single cell on the puzzle grid.
 *
 * @property position The coordinate (row, column) of the cell.
 * @property isEndpoint True if this cell contains one of the fixed colored dots to connect.
 * @property color The color of the endpoint dot or the color of the path occupying this cell (null if empty).
 * @property pathColor The color of the active path passing through this cell (null if no path is present).
 */
data class Cell(
    val position: Point,
    val isEndpoint: Boolean = false,
    val color: FlowColor? = null,
    val pathColor: FlowColor? = null
) {
    /**
     * Returns true if this cell is neither an endpoint nor traversed by any path.
     */
    val isEmpty: Boolean
        get() = !isEndpoint && pathColor == null

    /**
     * Returns true if this cell contains an endpoint or is traversed by a path.
     */
    val isOccupied: Boolean
        get() = isEndpoint || pathColor != null
}
