package com.zenflow.game.game.model

/**
 * Enumeration of available flow colors in ZenFlow puzzles.
 */
enum class FlowColor(val index: Int) {
    RED(0),
    BLUE(1),
    GREEN(2),
    YELLOW(3),
    PURPLE(4),
    ORANGE(5),
    PINK(6),
    CYAN(7);

    companion object {
        fun fromIndex(index: Int): FlowColor? = entries.find { it.index == index }
    }
}
