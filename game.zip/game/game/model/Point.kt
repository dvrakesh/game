package com.zenflow.game.game.model

import kotlin.math.abs

/**
 * Represents a discrete coordinate (row, column) on the game board.
 */
data class Point(val row: Int, val col: Int) {

    /**
     * Checks if this point is horizontally or vertically adjacent to [other].
     * Diagonal neighbors return false.
     */
    fun isAdjacentTo(other: Point): Boolean {
        val dRow = abs(row - other.row)
        val dCol = abs(col - other.col)
        return (dRow == 1 && dCol == 0) || (dRow == 0 && dCol == 1)
    }

    /**
     * Calculates the Manhattan distance between this point and [other].
     */
    fun manhattanDistanceTo(other: Point): Int {
        return abs(row - other.row) + abs(col - other.col)
    }

    operator fun plus(other: Point): Point = Point(row + other.row, col + other.col)

    operator fun minus(other: Point): Point = Point(row - other.row, col - other.col)
}
