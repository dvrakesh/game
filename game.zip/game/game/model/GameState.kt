package com.zenflow.game.game.model

/**
 * Data class representing the mutable state of an active puzzle session.
 *
 * @property level The puzzle definition being played.
 * @property grid 2D array representation of all cells on the board [row][col].
 * @property paths Map of active paths drawn by the player for each color.
 * @property currentDrawingColor The color currently being actively dragged/drawn by the player, or null if idle.
 * @property moveCount Total number of moves initiated in this attempt.
 * @property isCompleted True if all endpoints are connected and the entire grid is covered.
 * @property isPaused True if the gameplay is paused.
 * @property completionPercent Percentage of cells currently filled by paths (value from 0.0f to 1.0f).
 */
data class GameState(
    val level: Level,
    val grid: Array<Array<Cell>>,
    val paths: Map<FlowColor, List<Point>> = emptyMap(),
    val currentDrawingColor: FlowColor? = null,
    val moveCount: Int = 0,
    val isCompleted: Boolean = false,
    val isPaused: Boolean = false,
    val completionPercent: Float = 0f
) {
    /**
     * Integer percentage (0 to 100) for display in UI.
     */
    val completionPercentage: Int
        get() = (completionPercent * 100).coerceIn(0f, 100f).toInt()

    /**
     * Total number of flows required for this level.
     */
    val totalFlows: Int
        get() = level.numFlows

    /**
     * Safe lookup for a cell by coordinates.
     */
    fun getCell(row: Int, col: Int): Cell? {
        if (row in 0 until level.gridSize && col in 0 until level.gridSize) {
            return grid[row][col]
        }
        return null
    }

    /**
     * Safe lookup for a cell by Point.
     */
    fun getCell(point: Point): Cell? = getCell(point.row, point.col)

    /**
     * Checks if the flow for [color] is fully connected between its two endpoints.
     */
    fun isFlowConnected(color: FlowColor): Boolean {
        val path = paths[color] ?: return false
        if (path.size < 2) return false
        val endpoints = level.getEndpointsFor(color)
        if (endpoints.size != 2) return false
        val ep1 = endpoints[0]
        val ep2 = endpoints[1]
        val first = path.first()
        val last = path.last()
        return (first == ep1 && last == ep2) || (first == ep2 && last == ep1)
    }

    /**
     * Number of fully connected flows in the current state.
     */
    val connectedFlowsCount: Int
        get() = level.colors.count { isFlowConnected(it) }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as GameState

        if (level != other.level) return false
        if (!grid.contentDeepEquals(other.grid)) return false
        if (paths != other.paths) return false
        if (currentDrawingColor != other.currentDrawingColor) return false
        if (moveCount != other.moveCount) return false
        if (isCompleted != other.isCompleted) return false
        if (isPaused != other.isPaused) return false
        if (completionPercent != other.completionPercent) return false

        return true
    }

    override fun hashCode(): Int {
        var result = level.hashCode()
        result = 31 * result + grid.contentDeepHashCode()
        result = 31 * result + paths.hashCode()
        result = 31 * result + (currentDrawingColor?.hashCode() ?: 0)
        result = 31 * result + moveCount
        result = 31 * result + isCompleted.hashCode()
        result = 31 * result + isPaused.hashCode()
        result = 31 * result + completionPercent.hashCode()
        return result
    }

    companion object {
        /**
         * Factory method to create an initial GameState from a Level definition.
         */
        fun fromLevel(level: Level): GameState {
            val endpointMap = level.endpoints.toMap()
            val grid = Array(level.gridSize) { r ->
                Array(level.gridSize) { c ->
                    val point = Point(r, c)
                    val epColor = endpointMap[point]
                    Cell(
                        position = point,
                        isEndpoint = epColor != null,
                        color = epColor,
                        pathColor = null
                    )
                }
            }
            return GameState(
                level = level,
                grid = grid,
                paths = emptyMap(),
                currentDrawingColor = null,
                moveCount = 0,
                isCompleted = false,
                isPaused = false,
                completionPercent = 0f
            )
        }
    }
}
