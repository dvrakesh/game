package com.zenflow.game.game.model

/**
 * Data class representing the static configuration of a puzzle level.
 *
 * @property id Unique numeric identifier for the level (1-indexed).
 * @property gridSize The width and height of the square grid (e.g., 5 for a 5x5 board).
 * @property endpoints List of pairs mapping grid positions to their FlowColor endpoints.
 * @property chapter The name of the chapter this level belongs to (e.g., "Calm", "Flow").
 * @property chapterIndex The 0-based index of the chapter.
 * @property isUnlocked Whether this level is currently unlocked for the player (defaults to true for level 1).
 * @property bestMoves The minimum number of moves the player has used to solve this level (null if unsolved).
 */
data class Level(
    val id: Int,
    val gridSize: Int,
    val endpoints: List<Pair<Point, FlowColor>>,
    val chapter: String,
    val chapterIndex: Int,
    val isUnlocked: Boolean = (id == 1),
    val bestMoves: Int? = null
) {
    /**
     * Total number of cells on the board (gridSize * gridSize).
     */
    val totalCells: Int
        get() = gridSize * gridSize

    /**
     * The distinct flow colors present in this level.
     */
    val colors: Set<FlowColor>
        get() = endpoints.map { it.second }.toSet()

    /**
     * The total number of flows (color pairs) to be connected.
     */
    val numFlows: Int
        get() = endpoints.size / 2

    /**
     * Gets the pair of endpoints for a specific color.
     */
    fun getEndpointsFor(color: FlowColor): List<Point> =
        endpoints.filter { it.second == color }.map { it.first }
}
