package com.zenflow.game.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zenflow.game.game.data.LevelRepository
import com.zenflow.game.game.engine.PuzzleEngine
import com.zenflow.game.game.model.GameState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Shared tracker for unlocked levels and star ratings.
 * Keeps level unlock status synchronized across screens.
 */
object LevelProgressTracker {
    // Levels 1-3 unlocked by default for demo
    val unlockedLevels = mutableStateListOf(1, 2, 3)

    // Map of levelId -> stars earned (1..3)
    val completedLevels = mutableStateMapOf<Int, Int>()

    fun isUnlocked(levelId: Int): Boolean = unlockedLevels.contains(levelId)

    fun isCompleted(levelId: Int): Boolean = completedLevels.containsKey(levelId)

    fun getStars(levelId: Int): Int = completedLevels[levelId] ?: 0

    fun unlockLevel(levelId: Int) {
        if (!unlockedLevels.contains(levelId)) {
            unlockedLevels.add(levelId)
        }
    }

    fun completeLevel(levelId: Int, stars: Int) {
        val currentBest = completedLevels[levelId] ?: 0
        completedLevels[levelId] = maxOf(currentBest, stars)
        // Completing a level unlocks the next level
        unlockLevel(levelId + 1)
    }
}

/**
 * ViewModel managing the puzzle gameplay session.
 *
 * Exposes the active [GameState] and [timeElapsed] flows, delegates touch
 * inputs to the [PuzzleEngine], runs the gameplay timer, and records
 * progression and star achievements when a level is completed.
 */
class GameViewModel : ViewModel() {

    private val _gameState = MutableStateFlow<GameState?>(null)
    val gameState: StateFlow<GameState?> = _gameState.asStateFlow()

    private val _timeElapsed = MutableStateFlow(0L)
    val timeElapsed: StateFlow<Long> = _timeElapsed.asStateFlow()

    private val _currentLevelId = MutableStateFlow(1)
    val currentLevelId: StateFlow<Int> = _currentLevelId.asStateFlow()

    private var engine: PuzzleEngine? = null
    private var timerJob: Job? = null

    /**
     * Loads the specified level ID, initializes the puzzle engine,
     * and starts the elapsed time counter.
     */
    fun loadLevel(id: Int) {
        _currentLevelId.value = id
        val level = LevelRepository.getLevel(id) ?: return
        val newEngine = PuzzleEngine(level)
        engine = newEngine
        _gameState.value = newEngine.getState()
        _timeElapsed.value = 0L
        startTimer()
    }

    /**
     * Starts or restarts the elapsed time coroutine.
     */
    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                val state = _gameState.value
                if (state != null && !state.isCompleted && !state.isPaused) {
                    _timeElapsed.value += 1L
                }
            }
        }
    }

    /**
     * Dispatches touch down / tap event to the engine.
     */
    fun onTouchStart(row: Int, col: Int) {
        val eng = engine ?: return
        val newState = eng.onTouchStart(row, col)
        _gameState.value = newState
        checkCompletion(newState)
    }

    /**
     * Dispatches drag motion event to the engine.
     */
    fun onTouchMove(row: Int, col: Int) {
        val eng = engine ?: return
        val newState = eng.onTouchMove(row, col)
        _gameState.value = newState
        checkCompletion(newState)
    }

    /**
     * Dispatches touch release event to the engine.
     */
    fun onTouchEnd() {
        val eng = engine ?: return
        val newState = eng.onTouchEnd()
        _gameState.value = newState
        checkCompletion(newState)
    }

    /**
     * Resets the active puzzle to its initial unsolved configuration.
     */
    fun resetLevel() {
        val eng = engine ?: return
        val newState = eng.resetLevel()
        _gameState.value = newState
        _timeElapsed.value = 0L
        startTimer()
    }

    /**
     * Advances to the next level in sequence.
     */
    fun nextLevel() {
        val nextId = _currentLevelId.value + 1
        loadLevel(nextId)
    }

    /**
     * Evaluates whether the level is solved, stops the timer,
     * calculates stars, and unlocks the next level.
     */
    private fun checkCompletion(state: GameState) {
        if (state.isCompleted) {
            timerJob?.cancel()
            val stars = calculateStars(state)
            val levelId = _currentLevelId.value
            LevelProgressTracker.completeLevel(levelId, stars)
        }
    }

    /**
     * Calculates stars based on moves:
     * - 3 stars: Optimal moves (each color connected in 1 continuous stroke)
     * - 2 stars: Optimal moves + up to 2 revisions
     * - 1 star: Solved
     */
    private fun calculateStars(state: GameState): Int {
        val optimalMoves = state.level.numFlows
        val actualMoves = state.moveCount
        return when {
            actualMoves <= optimalMoves -> 3
            actualMoves <= optimalMoves + 2 -> 2
            else -> 1
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
