package com.zenflow.game.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

/**
 * Singleton settings manager holding reactive game audio and display preferences.
 * State is managed using Compose [mutableStateOf] so UI components recompose automatically.
 */
object GameSettings {
    var soundEnabled by mutableStateOf(true)
    var ambienceEnabled by mutableStateOf(true)
    var hapticEnabled by mutableStateOf(true)
    var animationsEnabled by mutableStateOf(true)

    fun toggleSound() {
        soundEnabled = !soundEnabled
    }

    fun toggleAmbience() {
        ambienceEnabled = !ambienceEnabled
    }

    fun toggleHaptic() {
        hapticEnabled = !hapticEnabled
    }

    fun toggleAnimations() {
        animationsEnabled = !animationsEnabled
    }
}

/**
 * ViewModel for interacting with [GameSettings].
 * Exposes convenience accessors and mutation methods for the Settings screen and other game screens.
 */
class SettingsViewModel : ViewModel() {
    val soundEnabled: Boolean
        get() = GameSettings.soundEnabled

    val ambienceEnabled: Boolean
        get() = GameSettings.ambienceEnabled

    val hapticEnabled: Boolean
        get() = GameSettings.hapticEnabled

    val animationsEnabled: Boolean
        get() = GameSettings.animationsEnabled

    fun toggleSound() = GameSettings.toggleSound()

    fun toggleAmbience() = GameSettings.toggleAmbience()

    fun toggleHaptic() = GameSettings.toggleHaptic()

    fun toggleAnimations() = GameSettings.toggleAnimations()

    fun setSound(enabled: Boolean) {
        GameSettings.soundEnabled = enabled
    }

    fun setAmbience(enabled: Boolean) {
        GameSettings.ambienceEnabled = enabled
    }

    fun setHaptic(enabled: Boolean) {
        GameSettings.hapticEnabled = enabled
    }

    fun setAnimations(enabled: Boolean) {
        GameSettings.animationsEnabled = enabled
    }
}
