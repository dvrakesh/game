package com.zenflow.game.engine

typealias PuzzleEngine = com.zenflow.game.game.engine.PuzzleEngine
