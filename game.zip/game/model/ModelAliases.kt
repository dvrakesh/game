package com.zenflow.game.model

typealias Point = com.zenflow.game.game.model.Point
typealias FlowColor = com.zenflow.game.game.model.FlowColor
typealias Cell = com.zenflow.game.game.model.Cell
typealias Level = com.zenflow.game.game.model.Level
typealias GameState = com.zenflow.game.game.model.GameState
