package com.zenflow.game.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.ui.components.ZenBackground
import com.zenflow.game.ui.components.ZenButton
import com.zenflow.game.ui.theme.*
import com.zenflow.game.viewmodel.GameSettings
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Full-screen bottom sheet dialog style Settings Screen for ZenFlow.
 *
 * Provides reactive toggles directly linked to [GameSettings],
 * information accordions for gameplay instructions and app details,
 * and custom Canvas-drawn icons throughout (no Material icon dependencies).
 */
@Composable
fun SettingsScreen(
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var howToPlayExpanded by remember { mutableStateOf(false) }
    var aboutExpanded by remember { mutableStateOf(false) }

    ZenBackground(modifier = modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.BottomCenter
        ) {
            // Main sheet container
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 16.dp)
                    .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                ZenDarkSurface.copy(alpha = 0.98f),
                                ZenDarkBg.copy(alpha = 0.99f),
                                ZenDarkBg
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                ZenGold.copy(alpha = 0.40f),
                                ZenDarkSurface.copy(alpha = 0.20f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
                    )
            ) {
                // Top drag / pill indicator
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp, bottom = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(42.dp)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(ZenMutedText.copy(alpha = 0.35f))
                    )
                }

                // Header with title, subtitle, and top close button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Make it Yours",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 26.sp,
                                letterSpacing = 0.5.sp,
                                color = ZenSoftWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Customize your relaxation experience",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = ZenMutedText,
                                fontSize = 13.sp
                            )
                        )
                    }

                    // Top circular close button
                    TopCloseButton(onClick = onClose)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable settings body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Section 1: Audio & Motion
                    SectionHeader(title = "SOUND & MOTION")

                    // Toggle 1: Soothing Sounds
                    SettingToggleRow(
                        title = "Soothing Sounds",
                        subtitle = "Chimes and completion tones",
                        checked = GameSettings.soundEnabled,
                        onCheckedChange = { GameSettings.soundEnabled = it },
                        icon = { isChecked ->
                            SoundWaveIcon(enabled = isChecked)
                        }
                    )

                    // Toggle 2: Calm Ambience
                    SettingToggleRow(
                        title = "Calm Ambience",
                        subtitle = "Background atmospheric melody",
                        checked = GameSettings.ambienceEnabled,
                        onCheckedChange = { GameSettings.ambienceEnabled = it },
                        icon = { isChecked ->
                            AmbienceMusicIcon(enabled = isChecked)
                        }
                    )

                    // Toggle 3: Gentle Touch
                    SettingToggleRow(
                        title = "Gentle Touch",
                        subtitle = "Tactile vibration feedback",
                        checked = GameSettings.hapticEnabled,
                        onCheckedChange = { GameSettings.hapticEnabled = it },
                        icon = { isChecked ->
                            HapticTouchIcon(enabled = isChecked)
                        }
                    )

                    // Toggle 4: Playful Motion
                    SettingToggleRow(
                        title = "Playful Motion",
                        subtitle = "Ambient particles and flow animations",
                        checked = GameSettings.animationsEnabled,
                        onCheckedChange = { GameSettings.animationsEnabled = it },
                        icon = { isChecked ->
                            SparkleMotionIcon(enabled = isChecked)
                        }
                    )

                    // Zen ornamental divider
                    ZenDivider()

                    // Section 2: Guide & Info
                    SectionHeader(title = "GUIDE & ABOUT")

                    // Info Row 1: How to Play
                    ExpandableInfoCard(
                        title = "How to Play",
                        subtitle = "Touch to view flow instructions",
                        expanded = howToPlayExpanded,
                        onToggle = { howToPlayExpanded = !howToPlayExpanded },
                        icon = { HowToPlayIcon() }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            InstructionStep(
                                number = "1",
                                title = "Connect Pairs",
                                desc = "Drag your finger to link matching colored orbs."
                            )
                            InstructionStep(
                                number = "2",
                                title = "No Crossing",
                                desc = "Flow paths cannot overlap or cut across one another."
                            )
                            InstructionStep(
                                number = "3",
                                title = "Fill the Board",
                                desc = "Cover every empty cell on the grid to complete the level."
                            )
                            InstructionStep(
                                number = "4",
                                title = "Earn 3 Stars",
                                desc = "Solve in the fewest possible moves for a perfect rating."
                            )
                        }
                    }

                    // Info Row 2: About ZenFlow
                    ExpandableInfoCard(
                        title = "About ZenFlow",
                        subtitle = "Version 1.0.0 • Mindful Puzzle",
                        expanded = aboutExpanded,
                        onToggle = { aboutExpanded = !aboutExpanded },
                        icon = { AboutZenIcon() }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "ZenFlow is crafted to provide a tranquil, meditative puzzle retreat. Let your thoughts settle as vibrant color streams bring harmony to every board.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = ZenSoftWhite.copy(alpha = 0.9f),
                                    lineHeight = 19.sp,
                                    fontSize = 13.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Version",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ZenMutedText)
                                )
                                Text(
                                    text = "1.0.0 (Release)",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = ZenGold,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Design",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ZenMutedText)
                                )
                                Text(
                                    text = "Jetpack Compose & Material 3",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ZenMutedText)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Fixed bottom close button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ZenDarkBg.copy(alpha = 0.95f))
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ZenButton(
                        text = "Close",
                        onClick = onClose,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

/**
 * Section title with subtle tracking and golden accent.
 */
@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.6.sp,
            fontSize = 11.sp,
            color = ZenGold.copy(alpha = 0.85f)
        ),
        modifier = Modifier.padding(start = 6.dp, top = 4.dp, bottom = 2.dp)
    )
}

/**
 * Elegant setting row containing a Canvas-drawn icon, text descriptions,
 * and a custom pill-shaped switch.
 */
@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: @Composable (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }

    val containerBg by animateColorAsState(
        targetValue = if (checked) ZenDarkCard.copy(alpha = 0.70f) else ZenDarkCard.copy(alpha = 0.35f),
        animationSpec = tween(durationMillis = 200),
        label = "SettingRowBg"
    )

    val iconBorderColor by animateColorAsState(
        targetValue = if (checked) ZenGold.copy(alpha = 0.40f) else ZenDarkSurface,
        animationSpec = tween(durationMillis = 200),
        label = "SettingIconBorder"
    )

    val iconBgColor by animateColorAsState(
        targetValue = if (checked) ZenGold.copy(alpha = 0.12f) else ZenDarkSurface.copy(alpha = 0.50f),
        animationSpec = tween(durationMillis = 200),
        label = "SettingIconBg"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(containerBg)
            .border(1.dp, ZenDarkSurface.copy(alpha = 0.8f), RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Switch,
                onClick = { onCheckedChange(!checked) }
            )
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Icon container
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(iconBgColor)
                .border(1.dp, iconBorderColor, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            icon(checked)
        }

        // Title & subtitle text
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = ZenSoftWhite
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    color = ZenMutedText
                )
            )
        }

        // Custom animated pill toggle switch
        ZenSwitch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

/**
 * Custom pill-shaped switch with gold accent when active and smooth thumb translation.
 */
@Composable
fun ZenSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val trackWidth = 50.dp
    val trackHeight = 28.dp
    val thumbSize = 20.dp
    val thumbPadding = 4.dp

    val trackColor by animateColorAsState(
        targetValue = if (checked) ZenGold else ZenDarkSurface,
        animationSpec = tween(durationMillis = 250),
        label = "ZenSwitchTrackColor"
    )

    val borderColor by animateColorAsState(
        targetValue = if (checked) Color(0xFFFFE066) else Color(0xFF2C3E5E),
        animationSpec = tween(durationMillis = 250),
        label = "ZenSwitchBorderColor"
    )

    val thumbColor by animateColorAsState(
        targetValue = if (checked) ZenDarkBg else ZenMutedText,
        animationSpec = tween(durationMillis = 250),
        label = "ZenSwitchThumbColor"
    )

    val thumbOffsetProgress by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "ZenSwitchThumbOffset"
    )

    Box(
        modifier = modifier
            .size(width = trackWidth, height = trackHeight)
            .shadow(
                elevation = if (checked) 4.dp else 0.dp,
                shape = CircleShape,
                ambientColor = if (checked) ZenGold.copy(alpha = 0.4f) else Color.Transparent,
                spotColor = if (checked) ZenGold.copy(alpha = 0.5f) else Color.Transparent
            )
            .clip(CircleShape)
            .background(trackColor)
            .border(1.5.dp, borderColor, CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Switch,
                onClick = { onCheckedChange(!checked) }
            ),
        contentAlignment = Alignment.CenterStart
    ) {
        // Compute thumb displacement
        val maxTravelPx = (trackWidth - thumbSize - (thumbPadding * 2)).value
        val currentOffsetDp = (thumbPadding.value + maxTravelPx * thumbOffsetProgress).dp

        Box(
            modifier = Modifier
                .offset { IntOffset(x = currentOffsetDp.roundToPx(), y = 0) }
                .size(thumbSize)
                .clip(CircleShape)
                .background(thumbColor)
        )
    }
}

/**
 * Expandable card for instruction rules and about information.
 */
@Composable
private fun ExpandableInfoCard(
    title: String,
    subtitle: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    val chevronRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(durationMillis = 250),
        label = "ChevronRotation"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ZenDarkCard.copy(alpha = 0.45f))
            .border(1.dp, ZenDarkSurface.copy(alpha = 0.8f), RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onToggle
            )
            .padding(16.dp)
            .animateContentSize(animationSpec = tween(durationMillis = 300))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Icon container
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ZenDarkSurface.copy(alpha = 0.6f))
                    .border(1.dp, ZenDarkSurface, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                icon()
            }

            // Title & subtitle
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = ZenSoftWhite
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        color = ZenMutedText
                    )
                )
            }

            // Rotating Chevron indicator
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .rotate(chevronRotation),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(12.dp)) {
                    val path = Path().apply {
                        moveTo(0f, size.height * 0.35f)
                        lineTo(size.width * 0.5f, size.height * 0.75f)
                        lineTo(size.width, size.height * 0.35f)
                    }
                    drawPath(
                        path = path,
                        color = ZenMutedText,
                        style = Stroke(
                            width = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(tween(200)) + expandVertically(tween(250)),
            exit = fadeOut(tween(150)) + shrinkVertically(tween(200))
        ) {
            content()
        }
    }
}

/**
 * Step layout item for the "How to Play" instructions.
 */
@Composable
private fun InstructionStep(
    number: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(ZenGold.copy(alpha = 0.15f))
                .border(1.dp, ZenGold.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = ZenGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = ZenSoftWhite,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            )
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = ZenMutedText,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            )
        }
    }
}

/**
 * Ornamental Zen divider with soft gold gradient and central rotating diamond.
 */
@Composable
private fun ZenDivider() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, ZenGold.copy(alpha = 0.35f))
                    )
                )
        )
        Box(
            modifier = Modifier
                .padding(horizontal = 10.dp)
                .size(6.dp)
                .rotate(45f)
                .background(ZenGold.copy(alpha = 0.65f))
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(ZenGold.copy(alpha = 0.35f), Color.Transparent)
                    )
                )
        )
    }
}

/**
 * Top circular close button with a crisp Canvas-drawn 'X'.
 */
@Composable
private fun TopCloseButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "CloseButtonScale"
    )

    Box(
        modifier = Modifier
            .scale(scale)
            .size(38.dp)
            .clip(CircleShape)
            .background(ZenDarkCard.copy(alpha = 0.85f))
            .border(1.dp, ZenDarkSurface, CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(13.dp)) {
            val stroke = 2.dp.toPx()
            drawLine(
                color = ZenSoftWhite.copy(alpha = 0.85f),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = ZenSoftWhite.copy(alpha = 0.85f),
                start = Offset(size.width, 0f),
                end = Offset(0f, size.height),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}

/**
 * Small circular gear button with a Canvas-drawn gear icon.
 * Can be placed on HomeScreen and GameScreen to open the settings bottom sheet dialog.
 */
@Composable
fun SettingsGearButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "SettingsGearScale"
    )

    Box(
        modifier = modifier
            .scale(scale)
            .size(42.dp)
            .clip(CircleShape)
            .background(ZenDarkCard.copy(alpha = 0.85f))
            .border(1.dp, ZenDarkSurface, CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(20.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val outerRadius = size.width * 0.44f
            val innerRadius = size.width * 0.30f
            val holeRadius = size.width * 0.16f
            val teeth = 6
            val toothAngle = (2 * PI / teeth).toFloat()
            val halfToothSpan = toothAngle * 0.22f

            val gearPath = Path().apply {
                for (i in 0 until teeth) {
                    val midAngle = i * toothAngle
                    val a1 = midAngle - halfToothSpan * 1.5f
                    val a2 = midAngle - halfToothSpan
                    val a3 = midAngle + halfToothSpan
                    val a4 = midAngle + halfToothSpan * 1.5f

                    val x1 = cx + innerRadius * cos(a1)
                    val y1 = cy + innerRadius * sin(a1)
                    val x2 = cx + outerRadius * cos(a2)
                    val y2 = cy + outerRadius * sin(a2)
                    val x3 = cx + outerRadius * cos(a3)
                    val y3 = cy + outerRadius * sin(a3)
                    val x4 = cx + innerRadius * cos(a4)
                    val y4 = cy + innerRadius * sin(a4)

                    if (i == 0) moveTo(x1, y1) else lineTo(x1, y1)
                    lineTo(x2, y2)
                    lineTo(x3, y3)
                    lineTo(x4, y4)
                }
                close()
            }

            // Draw outer gear body
            drawPath(path = gearPath, color = ZenSoftWhite)

            // Draw center cutout
            drawCircle(color = ZenDarkCard, radius = holeRadius, center = Offset(cx, cy))

            // Draw center golden axle pin
            drawCircle(color = ZenGold, radius = holeRadius * 0.45f, center = Offset(cx, cy))
        }
    }
}

// =========================================================================
// Canvas-drawn Icons (Zero Material Icon Dependencies)
// =========================================================================

/**
 * Canvas-drawn speaker sound effects icon.
 */
@Composable
private fun SoundWaveIcon(enabled: Boolean) {
    val iconColor = if (enabled) ZenGold else ZenMutedText.copy(alpha = 0.5f)

    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height

        // Speaker cone
        val speakerPath = Path().apply {
            moveTo(w * 0.14f, h * 0.35f)
            lineTo(w * 0.36f, h * 0.35f)
            lineTo(w * 0.62f, h * 0.16f)
            lineTo(w * 0.62f, h * 0.84f)
            lineTo(w * 0.36f, h * 0.65f)
            lineTo(w * 0.14f, h * 0.65f)
            close()
        }
        drawPath(speakerPath, color = iconColor)

        if (enabled) {
            // Inner sound wave arc
            val innerRect = Rect(
                center = Offset(w * 0.62f, h * 0.50f),
                radius = w * 0.18f
            )
            drawArc(
                color = iconColor,
                startAngle = -45f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = innerRect.topLeft,
                size = innerRect.size,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )

            // Outer sound wave arc
            val outerRect = Rect(
                center = Offset(w * 0.62f, h * 0.50f),
                radius = w * 0.32f
            )
            drawArc(
                color = iconColor.copy(alpha = 0.75f),
                startAngle = -45f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = outerRect.topLeft,
                size = outerRect.size,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        } else {
            // Mute diagonal line
            drawLine(
                color = ZenMutedText.copy(alpha = 0.7f),
                start = Offset(w * 0.72f, h * 0.34f),
                end = Offset(w * 0.88f, h * 0.66f),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = ZenMutedText.copy(alpha = 0.7f),
                start = Offset(w * 0.88f, h * 0.34f),
                end = Offset(w * 0.72f, h * 0.66f),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

/**
 * Canvas-drawn musical notes for background ambience.
 */
@Composable
private fun AmbienceMusicIcon(enabled: Boolean) {
    val iconColor = if (enabled) ZenGold else ZenMutedText.copy(alpha = 0.5f)

    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height

        // Left note head
        drawOval(
            color = iconColor,
            topLeft = Offset(w * 0.15f, h * 0.62f),
            size = Size(w * 0.26f, h * 0.20f)
        )

        // Right note head
        drawOval(
            color = iconColor,
            topLeft = Offset(w * 0.60f, h * 0.48f),
            size = Size(w * 0.26f, h * 0.20f)
        )

        // Stems
        val stemWidth = 2.dp.toPx()
        drawLine(
            color = iconColor,
            start = Offset(w * 0.39f, h * 0.70f),
            end = Offset(w * 0.39f, h * 0.22f),
            strokeWidth = stemWidth,
            cap = StrokeCap.Round
        )
        drawLine(
            color = iconColor,
            start = Offset(w * 0.84f, h * 0.56f),
            end = Offset(w * 0.84f, h * 0.14f),
            strokeWidth = stemWidth,
            cap = StrokeCap.Round
        )

        // Top connecting beam
        val beamPath = Path().apply {
            moveTo(w * 0.37f, h * 0.22f)
            lineTo(w * 0.86f, h * 0.14f)
            lineTo(w * 0.86f, h * 0.24f)
            lineTo(w * 0.37f, h * 0.32f)
            close()
        }
        drawPath(beamPath, color = iconColor)
    }
}

/**
 * Canvas-drawn haptic touch / vibration feedback icon.
 */
@Composable
private fun HapticTouchIcon(enabled: Boolean) {
    val iconColor = if (enabled) ZenGold else ZenMutedText.copy(alpha = 0.5f)

    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height

        // Device outline
        val phoneWidth = w * 0.40f
        val phoneHeight = h * 0.72f
        val phoneLeft = (w - phoneWidth) / 2f
        val phoneTop = (h - phoneHeight) / 2f

        drawRoundRect(
            color = iconColor,
            topLeft = Offset(phoneLeft, phoneTop),
            size = Size(phoneWidth, phoneHeight),
            cornerRadius = CornerRadius(3.5.dp.toPx(), 3.5.dp.toPx()),
            style = Stroke(width = 2.dp.toPx())
        )

        // Home / tactile dot
        drawCircle(
            color = iconColor,
            radius = 1.6.dp.toPx(),
            center = Offset(w * 0.5f, phoneTop + phoneHeight - 4.5.dp.toPx())
        )

        // Left vibration ripple
        val leftPath = Path().apply {
            moveTo(w * 0.18f, h * 0.32f)
            quadraticBezierTo(w * 0.08f, h * 0.50f, w * 0.18f, h * 0.68f)
        }
        drawPath(
            path = leftPath,
            color = iconColor,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )

        // Right vibration ripple
        val rightPath = Path().apply {
            moveTo(w * 0.82f, h * 0.32f)
            quadraticBezierTo(w * 0.92f, h * 0.50f, w * 0.82f, h * 0.68f)
        }
        drawPath(
            path = rightPath,
            color = iconColor,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

/**
 * Canvas-drawn sparkle star icon for animation / playful motion.
 */
@Composable
private fun SparkleMotionIcon(enabled: Boolean) {
    val iconColor = if (enabled) ZenGold else ZenMutedText.copy(alpha = 0.5f)

    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height

        // 4-point sparkle star drawer
        fun drawSparkle(cx: Float, cy: Float, radius: Float, color: Color) {
            val path = Path().apply {
                moveTo(cx, cy - radius)
                quadraticBezierTo(cx, cy, cx + radius, cy)
                quadraticBezierTo(cx, cy, cx, cy + radius)
                quadraticBezierTo(cx, cy, cx - radius, cy)
                quadraticBezierTo(cx, cy, cx, cy - radius)
                close()
            }
            drawPath(path, color = color)
        }

        // Primary center star
        drawSparkle(w * 0.44f, h * 0.52f, w * 0.38f, iconColor)
        // Secondary top-right star
        drawSparkle(w * 0.78f, h * 0.24f, w * 0.18f, iconColor.copy(alpha = 0.85f))
        // Tertiary tiny star bottom-left
        drawSparkle(w * 0.18f, h * 0.78f, w * 0.12f, iconColor.copy(alpha = 0.65f))
    }
}

/**
 * Canvas-drawn flow orbs icon for "How to Play".
 */
@Composable
private fun HowToPlayIcon() {
    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height

        // Elegant curved path connecting two orbs
        val flowPath = Path().apply {
            moveTo(w * 0.25f, h * 0.75f)
            cubicTo(
                w * 0.25f, h * 0.30f,
                w * 0.75f, h * 0.70f,
                w * 0.75f, h * 0.25f
            )
        }
        drawPath(
            path = flowPath,
            color = ZenGold.copy(alpha = 0.85f),
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
        )

        // Starting orb
        drawCircle(
            color = OrbCyan,
            radius = 4.2.dp.toPx(),
            center = Offset(w * 0.25f, h * 0.75f)
        )
        // Ending orb
        drawCircle(
            color = ZenGold,
            radius = 4.2.dp.toPx(),
            center = Offset(w * 0.75f, h * 0.25f)
        )
    }
}

/**
 * Canvas-drawn info icon for "About ZenFlow".
 */
@Composable
private fun AboutZenIcon() {
    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height

        // Outer circular ring
        drawCircle(
            color = ZenGold.copy(alpha = 0.80f),
            radius = w * 0.42f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = 1.8.dp.toPx())
        )

        // Dot of 'i'
        drawCircle(
            color = ZenGold,
            radius = 1.6.dp.toPx(),
            center = Offset(w * 0.5f, h * 0.33f)
        )

        // Stem of 'i'
        drawLine(
            color = ZenGold,
            start = Offset(w * 0.5f, h * 0.44f),
            end = Offset(w * 0.5f, h * 0.67f),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}
