package com.zenflow.game.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.game.data.LevelRepository
import com.zenflow.game.ui.components.ZenBackground
import com.zenflow.game.ui.theme.OrbCyan
import com.zenflow.game.ui.theme.ZenDarkBg
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenDarkSurface
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText
import com.zenflow.game.ui.theme.ZenSoftWhite
import com.zenflow.game.viewmodel.LevelProgressTracker
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Premium, meditative Home Screen for ZenFlow.
 *
 * Displays:
 * - Gradient background with floating ambient particle dots (via [ZenBackground])
 * - Elegant glowing "ZenFlow" title and "Relax Your Mind" subtitle
 * - Animated geometric Zen Lotus mandala with breathing pulse and slow rotation
 * - Large luxurious golden "PLAY" button with press scale and elevation
 * - Level completion progress pill indicator
 */
@Composable
fun HomeScreen(
    onPlayClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalLevels = remember {
        try {
            LevelRepository.getLevels().size.coerceAtLeast(30)
        } catch (_: Exception) {
            30
        }
    }
    val completedCount = LevelProgressTracker.completedLevels.size

    ZenBackground(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // -------------------------------------------------------------
            // Header: Title & Subtitle
            // -------------------------------------------------------------
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ZenFlow",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Light,
                        fontSize = 48.sp,
                        letterSpacing = 6.sp,
                        color = ZenSoftWhite,
                        shadow = Shadow(
                            color = ZenGold.copy(alpha = 0.55f),
                            offset = Offset(0f, 4f),
                            blurRadius = 24f
                        )
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "RELAX YOUR MIND",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Normal,
                        letterSpacing = 4.sp,
                        fontSize = 13.sp,
                        color = ZenMutedText
                    )
                )
            }

            // -------------------------------------------------------------
            // Centerpiece: Animated Zen Lotus Mandala
            // -------------------------------------------------------------
            ZenLotusMandala(
                modifier = Modifier
                    .size(240.dp)
                    .padding(12.dp)
            )

            // -------------------------------------------------------------
            // Bottom Section: Play Button & Progress Indicator
            // -------------------------------------------------------------
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                PlayButton(
                    onClick = onPlayClick,
                    modifier = Modifier
                        .fillMaxWidth(0.72f)
                        .height(62.dp)
                )

                // Level completion badge pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(ZenDarkCard.copy(alpha = 0.65f))
                        .border(
                            width = 1.dp,
                            color = ZenDarkSurface,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .padding(horizontal = 18.dp, vertical = 9.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Canvas(modifier = Modifier.size(14.dp)) {
                            // Custom mini 5-pointed star
                            val path = Path()
                            val outer = size.width / 2f
                            val inner = outer * 0.45f
                            val cx = size.width / 2f
                            val cy = size.height / 2f
                            var angle = -PI / 2.0
                            for (i in 0 until 10) {
                                val r = if (i % 2 == 0) outer else inner
                                val x = (cx + r * cos(angle)).toFloat()
                                val y = (cy + r * sin(angle)).toFloat()
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                                angle += PI / 5.0
                            }
                            path.close()
                            drawPath(path, color = ZenGold)
                        }

                        Text(
                            text = "Levels Completed: $completedCount/$totalLevels",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = ZenMutedText,
                                fontSize = 13.sp,
                                letterSpacing = 0.8.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Animated Zen Lotus Mandala with gentle breathing scale, slow rotating petals,
 * and glowing golden core.
 */
@Composable
private fun ZenLotusMandala(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ZenLotusTransition")

    // Gentle breathing scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LotusPulse"
    )

    // Ultra-slow continuous meditative rotation
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(75000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "LotusRotation"
    )

    Canvas(
        modifier = modifier.scale(pulseScale)
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = minOf(size.width, size.height) / 2f

        // 1. Ambient outer glow circle
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    ZenGold.copy(alpha = 0.18f),
                    OrbCyan.copy(alpha = 0.08f),
                    Color.Transparent
                ),
                center = center,
                radius = maxRadius * 1.1f
            ),
            radius = maxRadius * 1.1f,
            center = center
        )

        // 2. Outer Enso ring with meditative gap
        drawCircle(
            brush = Brush.sweepGradient(
                colors = listOf(
                    ZenGold.copy(alpha = 0.40f),
                    OrbCyan.copy(alpha = 0.25f),
                    Color.Transparent,
                    ZenGold.copy(alpha = 0.40f)
                ),
                center = center
            ),
            radius = maxRadius * 0.92f,
            center = center,
            style = Stroke(
                width = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        )

        // 3. Layer of 8 outer lotus petals
        val outerPetalLength = maxRadius * 0.76f
        val outerPetalWidth = maxRadius * 0.26f

        rotate(degrees = rotationAngle, pivot = center) {
            for (i in 0 until 8) {
                rotate(degrees = i * 45f, pivot = center) {
                    val petalPath = Path().apply {
                        moveTo(center.x, center.y)
                        cubicTo(
                            center.x - outerPetalWidth, center.y - outerPetalLength * 0.45f,
                            center.x - outerPetalWidth * 0.6f, center.y - outerPetalLength,
                            center.x, center.y - outerPetalLength
                        )
                        cubicTo(
                            center.x + outerPetalWidth * 0.6f, center.y - outerPetalLength,
                            center.x + outerPetalWidth, center.y - outerPetalLength * 0.45f,
                            center.x, center.y
                        )
                        close()
                    }

                    // Petal fill with gold-cyan gradient
                    drawPath(
                        path = petalPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                ZenGold.copy(alpha = 0.45f),
                                OrbCyan.copy(alpha = 0.20f),
                                Color.Transparent
                            ),
                            startY = center.y - outerPetalLength,
                            endY = center.y
                        )
                    )

                    // Petal outline
                    drawPath(
                        path = petalPath,
                        color = ZenGold.copy(alpha = 0.35f),
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                }
            }
        }

        // 4. Layer of 8 inner lotus petals (counter-rotated for harmonious motion)
        val innerPetalLength = maxRadius * 0.50f
        val innerPetalWidth = maxRadius * 0.18f

        rotate(degrees = -rotationAngle * 0.6f + 22.5f, pivot = center) {
            for (i in 0 until 8) {
                rotate(degrees = i * 45f, pivot = center) {
                    val innerPath = Path().apply {
                        moveTo(center.x, center.y)
                        cubicTo(
                            center.x - innerPetalWidth, center.y - innerPetalLength * 0.45f,
                            center.x - innerPetalWidth * 0.5f, center.y - innerPetalLength,
                            center.x, center.y - innerPetalLength
                        )
                        cubicTo(
                            center.x + innerPetalWidth * 0.5f, center.y - innerPetalLength,
                            center.x + innerPetalWidth, center.y - innerPetalLength * 0.45f,
                            center.x, center.y
                        )
                        close()
                    }

                    drawPath(
                        path = innerPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFFFE680).copy(alpha = 0.65f),
                                ZenGold.copy(alpha = 0.35f),
                                Color.Transparent
                            ),
                            startY = center.y - innerPetalLength,
                            endY = center.y
                        )
                    )

                    drawPath(
                        path = innerPath,
                        color = Color(0xFFFFE680).copy(alpha = 0.55f),
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                }
            }
        }

        // 5. Glowing center pearl / seed
        val coreRadius = maxRadius * 0.15f

        // Outer core glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    ZenGold,
                    ZenGold.copy(alpha = 0.4f),
                    Color.Transparent
                ),
                center = center,
                radius = coreRadius * 1.8f
            ),
            radius = coreRadius * 1.8f,
            center = center
        )

        // Solid core
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    Color(0xFFFFE680),
                    ZenGold
                ),
                center = Offset(center.x - coreRadius * 0.25f, center.y - coreRadius * 0.25f),
                radius = coreRadius
            ),
            radius = coreRadius,
            center = center
        )
    }
}

/**
 * Large, premium Play Button with golden gradient, smooth press bounce,
 * and high-contrast typography.
 */
@Composable
private fun PlayButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale = if (isPressed) 0.94f else 1.0f
    val buttonShape = RoundedCornerShape(32.dp)

    Box(
        modifier = modifier
            .scale(scale)
            .shadow(
                elevation = if (isPressed) 4.dp else 14.dp,
                shape = buttonShape,
                ambientColor = ZenGold.copy(alpha = 0.40f),
                spotColor = ZenGold.copy(alpha = 0.65f)
            )
            .clip(buttonShape)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFFE5A91A), // Burnished warm gold
                        ZenGold,           // Primary bright gold
                        Color(0xFFFFE066)  // Sunlit highlight
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.65f),
                        Color(0xFFB37E00)
                    )
                ),
                shape = buttonShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            // Play icon drawn with Canvas for crisp resolution
            Canvas(
                modifier = Modifier
                    .size(18.dp)
                    .padding(end = 4.dp)
            ) {
                val path = Path().apply {
                    moveTo(size.width * 0.2f, size.height * 0.1f)
                    lineTo(size.width * 0.9f, size.height * 0.5f)
                    lineTo(size.width * 0.2f, size.height * 0.9f)
                    close()
                }
                drawPath(path, color = ZenDarkBg)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = "P L A Y",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    letterSpacing = 3.sp,
                    color = ZenDarkBg
                )
            )
        }
    }
}
