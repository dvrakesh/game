package com.zenflow.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.game.data.LevelRepository
import com.zenflow.game.game.model.Level
import com.zenflow.game.ui.components.LevelCard
import com.zenflow.game.ui.components.ZenBackground
import com.zenflow.game.ui.theme.ZenDarkBg
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenDarkSurface
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText
import com.zenflow.game.ui.theme.ZenSoftWhite
import com.zenflow.game.viewmodel.LevelProgressTracker
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Level selection screen for ZenFlow.
 *
 * Displays:
 * - Top navigation bar with back button and "Select Level" header
 * - Scrollable list of chapters (Calm, Flow, Bloom, Glow, Zen)
 * - Chapter headers with descriptive emoji icons and grid sizes
 * - 3-column layout of [LevelCard] items representing levels
 * - Dynamic unlocked/completed/stars state bound to [LevelProgressTracker]
 */
@Composable
fun LevelSelectScreen(
    onLevelClick: (Int) -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val chapters = remember {
        val list = LevelRepository.getChapters()
        if (list.isNotEmpty()) list else listOf("Calm", "Flow", "Bloom", "Glow", "Zen")
    }

    // Total stars collected across all levels
    val totalStars = LevelProgressTracker.completedLevels.values.sum()

    ZenBackground(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // -------------------------------------------------------------
            // Top Navigation Bar
            // -------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Back Button with circular Zen background
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(ZenDarkCard.copy(alpha = 0.8f))
                        .border(1.dp, ZenDarkSurface, CircleShape)
                        .clickable(onClick = onBackClick),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(16.dp)) {
                        val path = Path().apply {
                            moveTo(size.width * 0.7f, size.height * 0.15f)
                            lineTo(size.width * 0.25f, size.height * 0.5f)
                            lineTo(size.width * 0.7f, size.height * 0.85f)
                        }
                        drawPath(
                            path = path,
                            color = ZenSoftWhite,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(
                                width = 2.dp.toPx(),
                                cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                join = androidx.compose.ui.graphics.StrokeJoin.Round
                            )
                        )
                    }
                }

                // Centered Screen Title
                Text(
                    text = "Select Level",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Medium,
                        fontSize = 20.sp,
                        letterSpacing = 1.sp,
                        color = ZenSoftWhite
                    )
                )

                // Total Stars Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(ZenDarkCard.copy(alpha = 0.8f))
                        .border(1.dp, ZenDarkSurface, RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Canvas(modifier = Modifier.size(12.dp)) {
                            val path = Path()
                            val outer = size.width / 2f
                            val inner = outer * 0.45f
                            val cx = size.width / 2f
                            val cy = size.height / 2f
                            var angle = -PI / 2.0
                            for (i in 0 until 10) {
                                val r = if (i % 2 == 0) outer else inner
                                val x = (cx + r * cos(angle)).toFloat()
                                val y = (cy + r * sin(angle)).toFloat()
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                                angle += PI / 5.0
                            }
                            path.close()
                            drawPath(path, color = ZenGold)
                        }

                        Text(
                            text = "$totalStars",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = ZenGold,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // Scrollable List of Chapter Sections
            // -------------------------------------------------------------
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                items(chapters) { chapterName ->
                    val chapterLevels = remember(chapterName) {
                        LevelRepository.getLevelsByChapter(chapterName)
                    }

                    ChapterSection(
                        chapterName = chapterName,
                        levels = chapterLevels,
                        onLevelClick = onLevelClick
                    )
                }

                // Bottom padding
                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

/**
 * Renders a single chapter section with header title and 3-column level cards grid.
 */
@Composable
private fun ChapterSection(
    chapterName: String,
    levels: List<Level>,
    onLevelClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val (emoji, subtitle) = getChapterMeta(chapterName)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Chapter Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = emoji,
                    fontSize = 18.sp
                )
                Text(
                    text = chapterName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = ZenSoftWhite,
                        fontSize = 17.sp,
                        letterSpacing = 0.5.sp
                    )
                )
            }

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = ZenMutedText,
                    fontSize = 12.sp,
                    letterSpacing = 0.5.sp
                )
            )
        }

        // 3-Column Grid of Level Cards
        val rows = levels.chunked(3)
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            rows.forEach { rowLevels ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowLevels.forEach { level ->
                        val isUnlocked = LevelProgressTracker.isUnlocked(level.id)
                        val isCompleted = LevelProgressTracker.isCompleted(level.id)
                        val stars = LevelProgressTracker.getStars(level.id)

                        LevelCard(
                            levelId = level.id,
                            isUnlocked = isUnlocked,
                            isCompleted = isCompleted,
                            stars = stars,
                            onClick = { onLevelClick(level.id) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Balance row if less than 3 cards
                    val missing = 3 - rowLevels.size
                    repeat(missing) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/**
 * Returns emoji and board size subtitle for each chapter.
 */
private fun getChapterMeta(chapterName: String): Pair<String, String> {
    return when (chapterName.lowercase()) {
        "calm" -> Pair("🌸", "5x5 Board")
        "flow" -> Pair("🌊", "6x6 Board")
        "bloom" -> Pair("🪷", "7x7 Board")
        "glow" -> Pair("✨", "7x7 Board")
        "zen" -> Pair("⛩️", "8x8 Board")
        else -> Pair("🌿", "Puzzle Board")
    }
}
