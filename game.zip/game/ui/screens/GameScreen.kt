package com.zenflow.game.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zenflow.game.ui.components.ProgressBar
import com.zenflow.game.ui.components.PuzzleBoard
import com.zenflow.game.ui.components.ZenBackground
import com.zenflow.game.ui.theme.OrbCyan
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenDarkSurface
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText
import com.zenflow.game.ui.theme.ZenSoftWhite
import com.zenflow.game.viewmodel.GameViewModel

/**
 * Main puzzle gameplay screen for ZenFlow.
 *
 * Displays:
 * - Top navigation bar: Back button, Level indicator & chapter name, Moves counter chip, Reset button
 * - Center area: Interactive [PuzzleBoard] canvas grid
 * - Bottom area: Radiant [ProgressBar] showing completion percentage and calming guidance hint
 * - Completion overlay: [LevelCompleteDialog] when the puzzle is solved
 */
@Composable
fun GameScreen(
    levelId: Int,
    onBackClick: () -> Unit,
    onNextLevel: (Int) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: GameViewModel = viewModel()
) {
    // Load requested level on entrance or when levelId changes
    LaunchedEffect(levelId) {
        viewModel.loadLevel(levelId)
    }

    val gameState by viewModel.gameState.collectAsState()
    val timeElapsed by viewModel.timeElapsed.collectAsState()

    val levelChapter = gameState?.level?.chapter ?: "Calm"
    val moveCount = gameState?.moveCount ?: 0
    val completionPercent = gameState?.completionPercent ?: 0f
    val isCompleted = gameState?.isCompleted ?: false

    Box(modifier = modifier.fillMaxSize()) {
        ZenBackground(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // ---------------------------------------------------------
                // 1. Top Bar: Back, Level Info, Moves Counter, Reset
                // ---------------------------------------------------------
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Back Button
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(ZenDarkCard.copy(alpha = 0.8f))
                            .border(1.dp, ZenDarkSurface, CircleShape)
                            .clickable(onClick = onBackClick),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(16.dp)) {
                            val path = Path().apply {
                                moveTo(size.width * 0.7f, size.height * 0.15f)
                                lineTo(size.width * 0.25f, size.height * 0.5f)
                                lineTo(size.width * 0.7f, size.height * 0.85f)
                            }
                            drawPath(
                                path = path,
                                color = ZenSoftWhite,
                                style = Stroke(
                                    width = 2.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }

                    // Level & Chapter Info
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Level $levelId",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 20.sp,
                                letterSpacing = 1.sp,
                                color = ZenSoftWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = levelChapter.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.sp,
                                letterSpacing = 2.sp,
                                color = ZenGold
                            )
                        )
                    }

                    // Right controls: Move Counter chip & Reset Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Move Counter Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(ZenDarkCard.copy(alpha = 0.8f))
                                .border(1.dp, ZenDarkSurface, RoundedCornerShape(16.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Moves: $moveCount",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = ZenMutedText,
                                    fontSize = 12.sp
                                )
                            )
                        }

                        // Reset Button
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(ZenDarkCard.copy(alpha = 0.8f))
                                .border(1.dp, ZenDarkSurface, CircleShape)
                                .clickable { viewModel.resetLevel() },
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.size(16.dp)) {
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val radius = size.width * 0.38f

                                // Circular arc with opening at top
                                drawArc(
                                    color = ZenSoftWhite,
                                    startAngle = -60f,
                                    sweepAngle = 280f,
                                    useCenter = false,
                                    style = Stroke(
                                        width = 1.8.dp.toPx(),
                                        cap = StrokeCap.Round
                                    )
                                )

                                // Arrowhead at the end of arc
                                val arrowPath = Path().apply {
                                    moveTo(center.x + radius * 0.4f, center.y - radius * 1.3f)
                                    lineTo(center.x + radius * 0.95f, center.y - radius * 0.85f)
                                    lineTo(center.x + radius * 0.3f, center.y - radius * 0.6f)
                                    close()
                                }
                                drawPath(arrowPath, color = ZenSoftWhite)
                            }
                        }
                    }
                }

                // ---------------------------------------------------------
                // 2. Center: The Interactive Puzzle Board
                // ---------------------------------------------------------
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    gameState?.let { state ->
                        PuzzleBoard(
                            gameState = state,
                            onTouchStart = { r, c -> viewModel.onTouchStart(r, c) },
                            onTouchMove = { r, c -> viewModel.onTouchMove(r, c) },
                            onTouchEnd = { viewModel.onTouchEnd() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                        )
                    }
                }

                // ---------------------------------------------------------
                // 3. Bottom: Progress Bar & Mindful Guidance Hint
                // ---------------------------------------------------------
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ProgressBar(
                        progress = completionPercent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    )

                    Text(
                        text = "Connect matching colors & cover the entire grid",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = ZenMutedText,
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        )
                    )
                }
            }
        }

        // -------------------------------------------------------------
        // 4. Level Completed Victory Dialog Overlay
        // -------------------------------------------------------------
        AnimatedVisibility(
            visible = isCompleted,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            gameState?.let { state ->
                LevelCompleteDialog(
                    gameState = state,
                    timeElapsed = timeElapsed,
                    onNextLevel = {
                        val nextId = levelId + 1
                        onNextLevel(nextId)
                    },
                    onReplay = {
                        viewModel.resetLevel()
                    },
                    onMenu = onBackClick
                )
            }
        }
    }
}
