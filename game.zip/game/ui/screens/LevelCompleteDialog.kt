package com.zenflow.game.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.game.model.GameState
import com.zenflow.game.ui.components.StarRating
import com.zenflow.game.ui.components.ZenButton
import com.zenflow.game.ui.theme.OrbCyan
import com.zenflow.game.ui.theme.ZenDarkBg
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenDarkSurface
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText
import com.zenflow.game.ui.theme.ZenSoftWhite
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Beautiful, triumphant completion dialog for ZenFlow.
 *
 * Displays:
 * - Semi-transparent darkened background with floating celebration sparkles
 * - Central elevated dialog card with rounded corners and gold ambient illumination
 * - "Level Complete!" heading in lustrous gold
 * - Animated stars (1-3) with spring scale entrance
 * - Move count and elapsed time breakdown
 * - 100% Flow completion badge
 * - Prominent "Next Level" button, outlined "Replay" button, and minimalist "Menu" button
 */
@Composable
fun LevelCompleteDialog(
    gameState: GameState,
    timeElapsed: Long,
    onNextLevel: () -> Unit,
    onReplay: () -> Unit,
    onMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val optimalMoves = gameState.level.numFlows
    val actualMoves = gameState.moveCount
    val stars = when {
        actualMoves <= optimalMoves -> 3
        actualMoves <= optimalMoves + 2 -> 2
        else -> 1
    }

    val minutes = timeElapsed / 60
    val seconds = timeElapsed % 60
    val formattedTime = if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"

    // Entrance animation for dialog card
    val cardScale = remember { Animatable(0.85f) }
    LaunchedEffect(Unit) {
        cardScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.78f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {} // Intercept taps
            ),
        contentAlignment = Alignment.Center
    ) {
        // Floating celebration sparkles in the background
        CelebrationSparkles(modifier = Modifier.fillMaxSize())

        // Dialog Card Container
        val dialogShape = RoundedCornerShape(28.dp)

        Column(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .scale(cardScale.value)
                .shadow(
                    elevation = 24.dp,
                    shape = dialogShape,
                    ambientColor = ZenGold.copy(alpha = 0.35f),
                    spotColor = ZenGold.copy(alpha = 0.60f)
                )
                .clip(dialogShape)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ZenDarkCard,
                            ZenDarkSurface,
                            ZenDarkBg
                        )
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            ZenGold.copy(alpha = 0.8f),
                            Color(0xFF2A3D66),
                            ZenGold.copy(alpha = 0.4f)
                        )
                    ),
                    shape = dialogShape
                )
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Heading
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Level Complete!",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        letterSpacing = 1.5.sp,
                        color = ZenGold,
                        shadow = Shadow(
                            color = ZenGold.copy(alpha = 0.5f),
                            offset = Offset(0f, 2f),
                            blurRadius = 16f
                        )
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "HARMONY RESTORED",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Normal,
                        letterSpacing = 3.sp,
                        color = ZenMutedText
                    )
                )
            }

            // Animated Stars
            StarRating(
                stars = stars,
                animated = true,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Statistics Grid: Moves, Time, Flow %
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ZenDarkCard.copy(alpha = 0.6f))
                    .border(1.dp, ZenDarkSurface, RoundedCornerShape(16.dp))
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatItem(label = "MOVES", value = "$actualMoves")
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(30.dp)
                        .background(ZenDarkSurface)
                )
                StatItem(label = "TIME", value = formattedTime)
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(30.dp)
                        .background(ZenDarkSurface)
                )
                StatItem(label = "FLOW", value = "100%")
            }

            // Actions: Next Level, Replay, Menu
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Next Level Button (Gold & Prominent)
                ZenButton(
                    text = "NEXT LEVEL",
                    onClick = onNextLevel,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                )

                // Replay Button (Outlined)
                OutlinedZenButton(
                    text = "REPLAY",
                    onClick = onReplay,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                )

                // Menu Button (Subtle Text Button)
                Text(
                    text = "Back to Menu",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = ZenMutedText,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            role = Role.Button,
                            onClick = onMenu
                        )
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }
    }
}

/**
 * Single statistic display item inside completion dialog.
 */
@Composable
private fun StatItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                letterSpacing = 1.5.sp,
                color = ZenMutedText
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = ZenSoftWhite
            )
        )
    }
}

/**
 * Outlined button for secondary actions (e.g. Replay).
 */
@Composable
private fun OutlinedZenButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(24.dp)

    Box(
        modifier = modifier
            .clip(shape)
            .background(ZenDarkCard.copy(alpha = 0.5f))
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF3B527D),
                        ZenGold.copy(alpha = 0.5f),
                        Color(0xFF3B527D)
                    )
                ),
                shape = shape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp,
                color = ZenSoftWhite
            )
        )
    }
}

/**
 * Ambient celebratory golden/cyan sparkling particles.
 */
@Composable
private fun CelebrationSparkles(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "SparklesTransition")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Sparkles"
    )

    Canvas(modifier = modifier) {
        if (size.width <= 0f || size.height <= 0f) return@Canvas

        val sparklePoints = listOf(
            Triple(0.2f, 0.25f, ZenGold),
            Triple(0.8f, 0.22f, OrbCyan),
            Triple(0.15f, 0.65f, ZenGold),
            Triple(0.85f, 0.68f, OrbCyan),
            Triple(0.3f, 0.15f, Color.White),
            Triple(0.7f, 0.18f, ZenGold),
            Triple(0.25f, 0.82f, OrbCyan),
            Triple(0.78f, 0.85f, ZenGold)
        )

        sparklePoints.forEachIndexed { i, (xRatio, yRatio, color) ->
            val phase = (animProgress + i * 0.125f) % 1.0f
            val alpha = sin(phase * PI).toFloat().coerceIn(0f, 1f)
            val radius = (3.dp.toPx() + sin(phase * 2 * PI).toFloat() * 1.5.dp.toPx()).coerceAtLeast(1f)

            val x = xRatio * size.width
            val y = yRatio * size.height

            // Glow
            drawCircle(
                color = color.copy(alpha = alpha * 0.4f),
                radius = radius * 2.5f,
                center = Offset(x, y)
            )
            // Core
            drawCircle(
                color = color.copy(alpha = alpha),
                radius = radius,
                center = Offset(x, y)
            )
        }
    }
}
