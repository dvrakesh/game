package com.zenflow.game.ui.theme

import androidx.compose.ui.graphics.Color

// Background colors - deep midnight/navy
val ZenDarkBg = Color(0xFF0A1628)
val ZenDarkSurface = Color(0xFF132038)
val ZenDarkCard = Color(0xFF1A2A4A)

// Accent colors for UI
val ZenGold = Color(0xFFFFD700)
val ZenSoftWhite = Color(0xFFF0F0F5)
val ZenMutedText = Color(0xFF8899BB)

// Puzzle orb colors - vibrant but soft
val OrbRed = Color(0xFFFF6B6B)
val OrbBlue = Color(0xFF4ECDC4)
val OrbGreen = Color(0xFF95E86B)
val OrbYellow = Color(0xFFFFE66D)
val OrbPurple = Color(0xFFAE8FDB)
val OrbOrange = Color(0xFFFF9F43)
val OrbPink = Color(0xFFFF78B4)
val OrbCyan = Color(0xFF54D7E0)

// List of orb colors for easy access
val OrbColors = listOf(OrbRed, OrbBlue, OrbGreen, OrbYellow, OrbPurple, OrbOrange, OrbPink, OrbCyan)
