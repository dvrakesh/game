package com.zenflow.game.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * A standalone animated glowing orb composable for menus, headers, and decorative elements.
 *
 * Features subtle pulsing scale and radial gradient glow animations.
 */
@Composable
fun GlowingOrb(
    color: Color,
    size: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "GlowingOrbTransition")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbPulseScale"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbGlowAlpha"
    )

    Canvas(
        modifier = modifier.size(size)
    ) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val orbRadius = (minOf(this.size.width, this.size.height) / 2f) * 0.65f

        // 1. Wide outer ambient glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    color.copy(alpha = glowAlpha * 0.50f),
                    color.copy(alpha = glowAlpha * 0.15f),
                    Color.Transparent
                ),
                center = center,
                radius = orbRadius * 1.55f * pulseScale
            ),
            radius = orbRadius * 1.55f * pulseScale,
            center = center
        )

        // 2. Focused mid-range aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    color.copy(alpha = glowAlpha * 0.85f),
                    color.copy(alpha = glowAlpha * 0.35f),
                    Color.Transparent
                ),
                center = center,
                radius = orbRadius * 1.25f * pulseScale
            ),
            radius = orbRadius * 1.25f * pulseScale,
            center = center
        )

        // 3. Spherical 3D shaded main orb
        val highlightOffset = center - Offset(orbRadius * 0.28f, orbRadius * 0.28f)
        val darkerEdge = Color(
            red = (color.red * 0.60f).coerceIn(0f, 1f),
            green = (color.green * 0.60f).coerceIn(0f, 1f),
            blue = (color.blue * 0.60f).coerceIn(0f, 1f),
            alpha = 1f
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.90f),
                    color,
                    darkerEdge
                ),
                center = highlightOffset,
                radius = orbRadius * 1.15f
            ),
            radius = orbRadius * pulseScale,
            center = center
        )

        // 4. White specular gloss reflection
        drawCircle(
            color = Color.White.copy(alpha = 0.50f),
            radius = orbRadius * 0.20f * pulseScale,
            center = highlightOffset
        )
    }
}
