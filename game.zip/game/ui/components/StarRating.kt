package com.zenflow.game.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Builds a geometric 5-pointed star path centered at [center].
 */
private fun createStarPath(center: Offset, outerRadius: Float, innerRadius: Float): Path {
    val path = Path()
    val numPoints = 5
    val angleStep = PI / numPoints
    var angle = -PI / 2.0 // Starts at the top vertex

    for (i in 0 until numPoints * 2) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val x = (center.x + r * cos(angle)).toFloat()
        val y = (center.y + r * sin(angle)).toFloat()
        if (i == 0) {
            path.moveTo(x, y)
        } else {
            path.lineTo(x, y)
        }
        angle += angleStep
    }
    path.close()
    return path
}

/**
 * Displays a 1-3 star rating with custom Canvas-drawn 5-pointed stars.
 *
 * Features:
 * - Filled stars in lustrous gradient gold with subtle warm glow
 * - Empty stars in sleek dark card fill with grey outlines
 * - Optional staggered spring entrance scale animation
 */
@Composable
fun StarRating(
    stars: Int,
    animated: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val starSizes = listOf(30.dp, 36.dp, 30.dp)

        for (i in 0 until 3) {
            val isFilled = i < stars
            val starSize = starSizes[i]

            SingleStar(
                isFilled = isFilled,
                size = starSize,
                index = i,
                animated = animated
            )
        }
    }
}

/**
 * Draws a single 5-pointed star with optional staggered bounce animation.
 */
@Composable
private fun SingleStar(
    isFilled: Boolean,
    size: Dp,
    index: Int,
    animated: Boolean
) {
    val scale = remember { Animatable(if (animated) 0f else 1f) }

    LaunchedEffect(isFilled, animated) {
        if (animated && isFilled) {
            scale.snapTo(0f)
            delay(index * 140L)
            scale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
        } else {
            scale.snapTo(1f)
        }
    }

    Canvas(
        modifier = Modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
    ) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val outerRadius = (minOf(this.size.width, this.size.height) / 2f) * 0.90f
        val innerRadius = outerRadius * 0.42f
        val starPath = createStarPath(center, outerRadius, innerRadius)

        if (isFilled) {
            // 1. Soft gold outer aura
            drawPath(
                path = starPath,
                color = ZenGold.copy(alpha = 0.28f),
                style = Stroke(width = outerRadius * 0.35f)
            )

            // 2. Rich gold vertical gradient fill
            drawPath(
                path = starPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFF275), // Sunlit highlight
                        ZenGold,           // Pure gold (0xFFFFD700)
                        Color(0xFFD49A00)  // Deep amber gold
                    ),
                    startY = center.y - outerRadius,
                    endY = center.y + outerRadius
                )
            )

            // 3. Crisp metallic edge outline
            drawPath(
                path = starPath,
                color = Color(0xFFFFE66D).copy(alpha = 0.85f),
                style = Stroke(width = 1.dp.toPx())
            )
        } else {
            // Empty Star: dark inner tile fill + muted grey outline
            drawPath(
                path = starPath,
                color = ZenDarkCard.copy(alpha = 0.60f)
            )
            drawPath(
                path = starPath,
                color = ZenMutedText.copy(alpha = 0.40f),
                style = Stroke(width = 1.5.dp.toPx())
            )
        }
    }
}
