package com.zenflow.game.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.ui.theme.OrbBlue
import com.zenflow.game.ui.theme.OrbCyan
import com.zenflow.game.ui.theme.OrbGreen
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenSoftWhite

/**
 * Custom progress bar for displaying puzzle completion percentage.
 *
 * Features:
 * - Rounded capsule shape
 * - ZenDarkCard background with subtle border
 * - Animated fill with a radiant teal-to-green gradient
 * - Centered high-legibility percentage text
 */
@Composable
fun ProgressBar(
    progress: Float,
    modifier: Modifier = Modifier
) {
    val clampedProgress = progress.coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = clampedProgress,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "ProgressBarAnimation"
    )

    val capsuleShape = CircleShape

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(26.dp)
            .clip(capsuleShape)
            .background(ZenDarkCard)
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF223555),
                        Color(0xFF334D78),
                        Color(0xFF223555)
                    )
                ),
                shape = capsuleShape
            ),
        contentAlignment = Alignment.CenterStart
    ) {
        // Animated gradient fill
        if (animatedProgress > 0.001f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedProgress)
                    .fillMaxHeight()
                    .clip(capsuleShape)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                OrbCyan,  // Color(0xFF54D7E0)
                                OrbBlue,  // Color(0xFF4ECDC4)
                                OrbGreen  // Color(0xFF95E86B)
                            )
                        )
                    )
            )
        }

        // Percentage text centered on the bar
        Text(
            text = "${(animatedProgress * 100).toInt()}%",
            modifier = Modifier.align(Alignment.Center),
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp,
                shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.65f),
                    offset = Offset(0f, 1.5f),
                    blurRadius = 3f
                )
            ),
            color = ZenSoftWhite
        )
    }
}
