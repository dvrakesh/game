package com.zenflow.game.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.ui.theme.ZenDarkBg
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText

/**
 * Premium custom styled button for ZenFlow.
 *
 * Features:
 * - Luxurious horizontal gold gradient background
 * - 24.dp rounded capsule shape with metallic top rim
 * - High-contrast dark typography
 * - Smooth spring-based press scale animation and dynamic elevation
 */
@Composable
fun ZenButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.94f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "ZenButtonScale"
    )

    val shape = RoundedCornerShape(24.dp)

    // Horizontal gold gradient: slightly darker gold to brilliant gold
    val activeGradient = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFFE5A91A), // Warm burnished gold
            ZenGold,           // Primary brilliant gold (0xFFFFD700)
            Color(0xFFFFE066)  // Sunlit gold highlight
        )
    )

    val disabledGradient = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF2C3545),
            Color(0xFF384357),
            Color(0xFF2C3545)
        )
    )

    Box(
        modifier = modifier
            .scale(scale)
            .shadow(
                elevation = if (enabled) (if (isPressed) 3.dp else 8.dp) else 0.dp,
                shape = shape,
                ambientColor = if (enabled) ZenGold.copy(alpha = 0.35f) else Color.Transparent,
                spotColor = if (enabled) ZenGold.copy(alpha = 0.50f) else Color.Transparent
            )
            .clip(shape)
            .background(if (enabled) activeGradient else disabledGradient)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = if (enabled) listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color(0xFFB37E00)
                    ) else listOf(
                        Color.White.copy(alpha = 0.10f),
                        Color(0xFF1E2633)
                    )
                ),
                shape = shape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .padding(horizontal = 28.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            ),
            color = if (enabled) ZenDarkBg else ZenMutedText.copy(alpha = 0.5f)
        )
    }
}
