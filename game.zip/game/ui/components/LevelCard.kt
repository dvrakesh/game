package com.zenflow.game.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zenflow.game.ui.theme.OrbCyan
import com.zenflow.game.ui.theme.ZenDarkBg
import com.zenflow.game.ui.theme.ZenDarkCard
import com.zenflow.game.ui.theme.ZenDarkSurface
import com.zenflow.game.ui.theme.ZenGold
import com.zenflow.game.ui.theme.ZenMutedText
import com.zenflow.game.ui.theme.ZenSoftWhite
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Level selection card for ZenFlow.
 *
 * Visual states:
 * 1. Completed: Gold border, checkmark badge, and star rating display
 * 2. Current (Unlocked & Incomplete): Subtle pulsing glowing border, ready to play
 * 3. Locked: Dimmed background, non-clickable, with custom Canvas padlock icon
 */
@Composable
fun LevelCard(
    levelId: Int,
    isUnlocked: Boolean,
    isCompleted: Boolean,
    stars: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth press scale bounce for unlocked levels
    val scale by animateFloatAsState(
        targetValue = if (isPressed && isUnlocked) 0.93f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "LevelCardPressScale"
    )

    // Pulsing border animation for current unlocked level
    val infiniteTransition = rememberInfiniteTransition(label = "CurrentLevelPulseTransition")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CurrentBorderPulse"
    )

    val cardShape = RoundedCornerShape(16.dp)

    // Dynamic border depending on state
    val borderModifier = when {
        !isUnlocked -> Modifier.border(
            width = 1.dp,
            color = Color(0xFF1E2E48).copy(alpha = 0.40f),
            shape = cardShape
        )
        isCompleted -> Modifier.border(
            width = 1.5.dp,
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFFEA80),
                    ZenGold,
                    Color(0xFFCC9900)
                )
            ),
            shape = cardShape
        )
        else -> Modifier.border(
            width = 2.dp,
            brush = Brush.sweepGradient(
                colors = listOf(
                    ZenGold.copy(alpha = pulseAlpha),
                    OrbCyan.copy(alpha = pulseAlpha),
                    ZenGold.copy(alpha = pulseAlpha)
                )
            ),
            shape = cardShape
        )
    }

    val cardBackground = when {
        !isUnlocked -> ZenDarkSurface.copy(alpha = 0.50f)
        isCompleted -> ZenDarkCard
        else -> ZenDarkCard
    }

    Box(
        modifier = modifier
            .scale(scale)
            .aspectRatio(1f)
            .shadow(
                elevation = if (isUnlocked) (if (isPressed) 2.dp else 6.dp) else 0.dp,
                shape = cardShape,
                ambientColor = if (isCompleted) ZenGold.copy(alpha = 0.20f) else Color(0x33000000),
                spotColor = if (isCompleted) ZenGold.copy(alpha = 0.30f) else Color(0x66000000)
            )
            .clip(cardShape)
            .background(cardBackground)
            .then(borderModifier)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = isUnlocked,
                role = Role.Button,
                onClick = onClick
            )
            .padding(8.dp)
    ) {
        // Top-right status badge (Checkmark if completed)
        if (isCompleted) {
            Canvas(
                modifier = Modifier
                    .size(18.dp)
                    .align(Alignment.TopEnd)
            ) {
                val w = size.width
                val h = size.height

                // Badge background
                drawCircle(
                    color = ZenGold.copy(alpha = 0.20f),
                    radius = w / 2f,
                    center = Offset(w / 2f, h / 2f)
                )
                drawCircle(
                    color = ZenGold,
                    radius = w / 2f,
                    center = Offset(w / 2f, h / 2f),
                    style = Stroke(width = 1.dp.toPx())
                )

                // Checkmark path
                val checkPath = Path().apply {
                    moveTo(w * 0.28f, h * 0.52f)
                    lineTo(w * 0.44f, h * 0.68f)
                    lineTo(w * 0.74f, h * 0.34f)
                }
                drawPath(
                    path = checkPath,
                    color = ZenGold,
                    style = Stroke(
                        width = 1.8.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }

        // Center Content
        if (!isUnlocked) {
            // Locked icon + dimmed level number
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                LockIcon(modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = levelId.toString(),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    ),
                    color = ZenMutedText.copy(alpha = 0.35f)
                )
            }
        } else {
            // Unlocked level display
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = levelId.toString(),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    ),
                    color = if (isCompleted) ZenSoftWhite else Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                if (isCompleted) {
                    MiniStarRow(stars = stars)
                } else {
                    // Current level badge
                    Text(
                        text = "PLAY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp,
                            letterSpacing = 1.sp
                        ),
                        color = ZenGold.copy(alpha = pulseAlpha)
                    )
                }
            }
        }
    }
}

/**
 * Draws a Canvas padlock icon for locked levels.
 */
@Composable
private fun LockIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Shackle arch
        val shackleRadius = w * 0.26f
        val shackleTop = h * 0.12f
        val shackleLeft = (w - shackleRadius * 2f) / 2f
        drawArc(
            color = ZenMutedText.copy(alpha = 0.45f),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(shackleLeft, shackleTop),
            size = Size(shackleRadius * 2f, shackleRadius * 2f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )

        // Lock body
        val bodyTop = shackleTop + shackleRadius
        val bodyW = w * 0.72f
        val bodyH = h * 0.50f
        val bodyLeft = (w - bodyW) / 2f

        drawRoundRect(
            color = Color(0xFF16233B),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyW, bodyH),
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = ZenMutedText.copy(alpha = 0.50f),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyW, bodyH),
            cornerRadius = CornerRadius(4f, 4f),
            style = Stroke(width = 1.2.dp.toPx())
        )

        // Keyhole
        val keyholeCenter = Offset(w / 2f, bodyTop + bodyH * 0.42f)
        drawCircle(
            color = ZenDarkBg,
            radius = 2.dp.toPx(),
            center = keyholeCenter
        )
        drawLine(
            color = ZenDarkBg,
            start = keyholeCenter,
            end = Offset(keyholeCenter.x, keyholeCenter.y + 3.dp.toPx()),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

/**
 * Renders a compact row of 3 mini stars for the completed level card.
 */
@Composable
private fun MiniStarRow(stars: Int) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until 3) {
            val isFilled = i < stars
            Canvas(modifier = Modifier.size(11.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val outerRadius = size.width / 2f
                val innerRadius = outerRadius * 0.42f

                val path = Path()
                val numPoints = 5
                val angleStep = PI / numPoints
                var angle = -PI / 2.0

                for (p in 0 until numPoints * 2) {
                    val r = if (p % 2 == 0) outerRadius else innerRadius
                    val x = (center.x + r * cos(angle)).toFloat()
                    val y = (center.y + r * sin(angle)).toFloat()
                    if (p == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    angle += angleStep
                }
                path.close()

                if (isFilled) {
                    drawPath(path = path, color = ZenGold)
                } else {
                    drawPath(
                        path = path,
                        color = ZenMutedText.copy(alpha = 0.35f),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
            }
        }
    }
}
