package com.zenflow.game.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.zenflow.game.ui.theme.*
import kotlin.math.PI
import kotlin.math.sin

/**
 * Metadata for a single ambient zen particle.
 */
private data class AmbientParticle(
    val xRatio: Float,
    val initialYRatio: Float,
    val sizeDp: Float,
    val speed: Float,
    val driftAmplitude: Float,
    val driftFrequency: Float,
    val baseAlpha: Float,
    val color: Color
)

/**
 * Reusable full-screen animated background for ZenFlow.
 *
 * Combines a rich dark gradient with 18 softly drifting, glowing particles
 * that slowly float upward and fade in and out.
 */
@Composable
fun ZenBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    // 18 pre-configured atmospheric particles with varying properties
    val particles = remember {
        listOf(
            AmbientParticle(0.12f, 0.15f, 3.5f, 0.85f, 16f, 1.2f, 0.35f, OrbCyan),
            AmbientParticle(0.28f, 0.42f, 2.0f, 0.70f, 12f, 0.9f, 0.25f, ZenGold),
            AmbientParticle(0.45f, 0.88f, 4.5f, 1.15f, 20f, 1.5f, 0.38f, OrbPurple),
            AmbientParticle(0.63f, 0.25f, 2.5f, 0.80f, 14f, 1.1f, 0.30f, OrbBlue),
            AmbientParticle(0.82f, 0.65f, 5.0f, 1.25f, 22f, 1.7f, 0.40f, ZenSoftWhite),
            AmbientParticle(0.18f, 0.75f, 3.0f, 0.95f, 18f, 1.3f, 0.32f, OrbGreen),
            AmbientParticle(0.35f, 0.05f, 4.0f, 1.10f, 15f, 1.0f, 0.36f, OrbPink),
            AmbientParticle(0.52f, 0.55f, 2.2f, 0.65f, 10f, 0.8f, 0.22f, ZenGold),
            AmbientParticle(0.74f, 0.35f, 3.8f, 1.05f, 17f, 1.4f, 0.30f, OrbCyan),
            AmbientParticle(0.91f, 0.80f, 2.8f, 0.75f, 13f, 0.95f, 0.28f, OrbPurple),
            AmbientParticle(0.08f, 0.92f, 4.2f, 1.20f, 21f, 1.6f, 0.38f, OrbBlue),
            AmbientParticle(0.22f, 0.58f, 2.2f, 0.68f, 11f, 0.85f, 0.24f, ZenSoftWhite),
            AmbientParticle(0.40f, 0.30f, 5.5f, 1.30f, 24f, 1.8f, 0.42f, OrbYellow),
            AmbientParticle(0.58f, 0.12f, 3.2f, 0.90f, 16f, 1.25f, 0.32f, OrbPink),
            AmbientParticle(0.70f, 0.70f, 2.4f, 0.78f, 12f, 1.0f, 0.26f, OrbCyan),
            AmbientParticle(0.88f, 0.18f, 4.8f, 1.22f, 20f, 1.55f, 0.38f, ZenGold),
            AmbientParticle(0.31f, 0.82f, 2.6f, 0.82f, 14f, 1.15f, 0.28f, OrbGreen),
            AmbientParticle(0.67f, 0.48f, 3.6f, 1.00f, 18f, 1.35f, 0.34f, OrbPurple)
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ZenBackgroundTransition")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ZenParticleProgress"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        ZenDarkBg,
                        Color(0xFF0F1E36),
                        ZenDarkBg
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (size.width <= 0f || size.height <= 0f) return@Canvas

            particles.forEach { p ->
                // Particles drift upwards; wrap when past top
                val rawY = (p.initialYRatio - progress * p.speed) % 1.0f
                val yRatio = if (rawY < 0f) rawY + 1.0f else rawY
                val y = yRatio * size.height

                // Horizontal drift with sine oscillation
                val driftPx = p.driftAmplitude.dp.toPx()
                val drift = sin((progress * p.driftFrequency + p.xRatio) * 2.0 * PI).toFloat() * driftPx
                val x = (p.xRatio * size.width + drift).coerceIn(0f, size.width)

                // Smooth fade-in near bottom, fade-out near top
                val verticalFade = sin(yRatio * PI).toFloat().coerceIn(0f, 1f)
                val alpha = (p.baseAlpha * verticalFade).coerceIn(0f, 1f)

                val radius = (p.sizeDp.dp.toPx() / 2f)

                // 1. Soft atmospheric outer glow
                drawCircle(
                    color = p.color.copy(alpha = alpha * 0.30f),
                    radius = radius * 2.4f,
                    center = Offset(x, y)
                )

                // 2. Core particle
                drawCircle(
                    color = p.color.copy(alpha = alpha),
                    radius = radius,
                    center = Offset(x, y)
                )
            }
        }

        // Foreground content
        content()
    }
}
