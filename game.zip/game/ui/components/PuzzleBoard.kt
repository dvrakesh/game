package com.zenflow.game.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.zenflow.game.game.model.Cell
import com.zenflow.game.game.model.FlowColor
import com.zenflow.game.game.model.GameState
import com.zenflow.game.game.model.Point
import com.zenflow.game.ui.theme.*

/**
 * Interactive puzzle board grid for ZenFlow.
 *
 * Renders the square puzzle grid using Canvas with smooth path drawing,
 * glowing endpoint orbs, cell fills, and comprehensive touch gesture handling.
 */
@Composable
fun PuzzleBoard(
    gameState: GameState,
    onTouchStart: (Int, Int) -> Unit,
    onTouchMove: (Int, Int) -> Unit,
    onTouchEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val grid = gameState.grid
    val rows = grid.size.coerceAtLeast(1)
    val cols = if (grid.isNotEmpty() && grid[0].isNotEmpty()) grid[0].size else rows

    var currentCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = Color(0x66000000),
                spotColor = Color(0xAA000000)
            )
            .clip(RoundedCornerShape(20.dp))
            .background(ZenDarkSurface)
            .border(
                width = 2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF2A3D66),
                        Color(0xFF162540),
                        Color(0xFF2A3D66)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .pointerInput(rows, cols) {
                detectTapGestures(
                    onTap = { offset ->
                        val cellSize = size.width / cols
                        val r = (offset.y / cellSize).toInt().coerceIn(0, rows - 1)
                        val c = (offset.x / cellSize).toInt().coerceIn(0, cols - 1)
                        onTouchStart(r, c)
                        onTouchEnd()
                    }
                )
            }
            .pointerInput(rows, cols) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val cellSize = size.width / cols
                        val r = (offset.y / cellSize).toInt().coerceIn(0, rows - 1)
                        val c = (offset.x / cellSize).toInt().coerceIn(0, cols - 1)
                        currentCell = Pair(r, c)
                        onTouchStart(r, c)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val cellSize = size.width / cols
                        val r = (change.position.y / cellSize).toInt()
                        val c = (change.position.x / cellSize).toInt()
                        if (r in 0 until rows && c in 0 until cols) {
                            if (currentCell?.first != r || currentCell?.second != c) {
                                currentCell = Pair(r, c)
                                onTouchMove(r, c)
                            }
                        }
                    },
                    onDragEnd = {
                        currentCell = null
                        onTouchEnd()
                    },
                    onDragCancel = {
                        currentCell = null
                        onTouchEnd()
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (rows <= 0 || cols <= 0) return@Canvas

            val cellWidth = size.width / cols
            val cellHeight = size.height / rows
            val cellSize = minOf(cellWidth, cellHeight)
            val pathStrokeWidth = cellSize * 0.60f
            val orbRadius = cellSize * 0.35f

            // Helper to resolve FlowColor to Theme Color
            fun colorForFlow(flowColor: FlowColor?): Color {
                if (flowColor == null) return Color.Transparent
                val index = flowColor.index
                return OrbColors.getOrElse(index) {
                    OrbColors.getOrElse(flowColor.ordinal) { OrbRed }
                }
            }

            // -------------------------------------------------------------
            // LAYER 1: Grid background & individual cell cards
            // -------------------------------------------------------------
            val cellPadding = 2f
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cellLeft = c * cellWidth + cellPadding
                    val cellTop = r * cellHeight + cellPadding
                    val cellW = cellWidth - cellPadding * 2f
                    val cellH = cellHeight - cellPadding * 2f

                    // Subtle cell tile
                    drawRoundRect(
                        color = ZenDarkCard.copy(alpha = 0.45f),
                        topLeft = Offset(cellLeft, cellTop),
                        size = Size(cellW, cellH),
                        cornerRadius = CornerRadius(8f, 8f)
                    )

                    // Subtle inner cell border
                    drawRoundRect(
                        color = Color(0xFF1E3050).copy(alpha = 0.5f),
                        topLeft = Offset(cellLeft, cellTop),
                        size = Size(cellW, cellH),
                        cornerRadius = CornerRadius(8f, 8f),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
            }

            // -------------------------------------------------------------
            // LAYER 2: Paths
            // -------------------------------------------------------------
            gameState.paths.forEach { (color, points) ->
                if (points.isNotEmpty()) {
                    val orbColor = colorForFlow(color)

                    if (points.size == 1) {
                        // Single cell path dot
                        val p = points[0]
                        val center = Offset(
                            p.col * cellWidth + cellWidth / 2f,
                            p.row * cellHeight + cellHeight / 2f
                        )
                        drawCircle(
                            color = orbColor.copy(alpha = 0.60f),
                            radius = pathStrokeWidth / 2f,
                            center = center
                        )
                    } else {
                        val path = Path()
                        val first = points.first()
                        path.moveTo(
                            first.col * cellWidth + cellWidth / 2f,
                            first.row * cellHeight + cellHeight / 2f
                        )

                        for (i in 1 until points.size) {
                            val pt = points[i]
                            path.lineTo(
                                pt.col * cellWidth + cellWidth / 2f,
                                pt.row * cellHeight + cellHeight / 2f
                            )
                        }

                        // Subtle outer path glow
                        drawPath(
                            path = path,
                            color = orbColor.copy(alpha = 0.22f),
                            style = Stroke(
                                width = pathStrokeWidth * 1.25f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )

                        // Main path line (60% alpha)
                        drawPath(
                            path = path,
                            color = orbColor.copy(alpha = 0.60f),
                            style = Stroke(
                                width = pathStrokeWidth,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )

                        // Bright inner luminous core line
                        drawPath(
                            path = path,
                            color = orbColor.copy(alpha = 0.90f),
                            style = Stroke(
                                width = pathStrokeWidth * 0.35f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // LAYER 3: Path fills (cells with pathColor get 15% alpha)
            // -------------------------------------------------------------
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cell = grid.getOrNull(r)?.getOrNull(c) ?: continue
                    val pathColor = cell.pathColor
                    if (pathColor != null) {
                        val orbColor = colorForFlow(pathColor)
                        drawRoundRect(
                            color = orbColor.copy(alpha = 0.15f),
                            topLeft = Offset(c * cellWidth + 2f, r * cellHeight + 2f),
                            size = Size(cellWidth - 4f, cellHeight - 4f),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // LAYER 4: Endpoints (Orbs)
            // -------------------------------------------------------------
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cell = grid.getOrNull(r)?.getOrNull(c) ?: continue
                    if (cell.isEndpoint && cell.color != null) {
                        val orbColor = colorForFlow(cell.color)
                        val center = Offset(
                            c * cellWidth + cellWidth / 2f,
                            r * cellHeight + cellHeight / 2f
                        )

                        // 1. Subtle outer glow behind orb
                        drawCircle(
                            color = orbColor.copy(alpha = 0.25f),
                            radius = orbRadius * 1.35f,
                            center = center
                        )
                        drawCircle(
                            color = orbColor.copy(alpha = 0.12f),
                            radius = orbRadius * 1.55f,
                            center = center
                        )

                        // 2. Darker edge color for spherical 3D effect
                        val darkerEdge = Color(
                            red = (orbColor.red * 0.65f).coerceIn(0f, 1f),
                            green = (orbColor.green * 0.65f).coerceIn(0f, 1f),
                            blue = (orbColor.blue * 0.65f).coerceIn(0f, 1f),
                            alpha = 1f
                        )

                        // 3. Radial gradient from bright center to darker edge
                        val lightCenter = center - Offset(orbRadius * 0.22f, orbRadius * 0.22f)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.85f),
                                    orbColor,
                                    darkerEdge
                                ),
                                center = lightCenter,
                                radius = orbRadius * 1.15f
                            ),
                            radius = orbRadius,
                            center = center
                        )

                        // 4. White specular gloss dot
                        drawCircle(
                            color = Color.White.copy(alpha = 0.55f),
                            radius = orbRadius * 0.22f,
                            center = lightCenter
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // LAYER 5: Grid overlay for depth
            // -------------------------------------------------------------
            for (c in 1 until cols) {
                val x = c * cellWidth
                drawLine(
                    color = Color(0xFF223558).copy(alpha = 0.35f),
                    start = Offset(x, 0f),
                    end = Offset(x, size.height),
                    strokeWidth = 1.dp.toPx()
                )
            }
            for (r in 1 until rows) {
                val y = r * cellHeight
                drawLine(
                    color = Color(0xFF223558).copy(alpha = 0.35f),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }
        }
    }
}
